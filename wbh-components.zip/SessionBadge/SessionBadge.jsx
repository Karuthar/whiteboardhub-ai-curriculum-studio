import { useSession } from "../../contexts/SessionContext";

export default function SessionBadge(){

    const session = useSession();

    return(

        <div className="session-badge">

            {
                session.guest
                ? "Guest Workspace"
                : "Registered Workspace"
            }

        </div>

    );

}