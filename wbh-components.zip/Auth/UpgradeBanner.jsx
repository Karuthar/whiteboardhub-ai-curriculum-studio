export default function UpgradeBanner({onUpgrade}){

    return(

        <div className="upgrade-banner">

            <strong>Guest Workspace</strong>

            <p>

                Save your work permanently, sync across devices,
                publish documents to the Marketplace and earn royalties.

            </p>

            <button onClick={onUpgrade}>

                Create Free Account

            </button>

        </div>

    );

}