import { useEffect } from "react";

import { useEditor, EditorContent } from "@tiptap/react";

import StarterKit from "@tiptap/starter-kit";

import { Table } from "@tiptap/extension-table";
import { TableRow } from "@tiptap/extension-table-row";
import { TableCell } from "@tiptap/extension-table-cell";
import { TableHeader } from "@tiptap/extension-table-header";

import ResizeImage from "tiptap-extension-resize-image";

export default function RichTextEditor({
  content,
  onChange,
  selectedResource
}) {

  const editor = useEditor({
    extensions: [
      StarterKit,

      Table.configure({
        resizable: true
      }),

      TableRow,
      TableHeader,
      TableCell,

      ResizeImage
    ],

    content: content || "",

    onUpdate({ editor }) {
      onChange(editor.getHTML());
    }
  });

  useEffect(() => {

    if (
      editor &&
      content &&
      content !== editor.getHTML()
    ) {
      editor.commands.setContent(content);
    }

  }, [content, editor]);

  if (!editor) return null;

  function getResourceUrl(resource) {

    return (
      resource?.url ||
      `http://localhost:7000${resource?.previewUrl || ""}`
    );
  }

  function insertSelectedResource() {
  if (!selectedResource) {
    alert("Select a resource first.");
    return;
  }

  const resourceUrl = getResourceUrl(selectedResource);

  const resourceName =
    selectedResource.title ||
    selectedResource.originalFileName ||
    selectedResource.name ||
    "Learning Resource";

  const isImage =
    selectedResource.resourceType === "image" ||
    selectedResource.mimeType?.startsWith("image/");

  const isVideo =
    selectedResource.resourceType === "video" ||
    selectedResource.mimeType?.startsWith("video/");

  if (isImage) {
    editor
      .chain()
      .focus()
      .insertContent(`
        <div class="inserted-resource-block">
          <p>
            <strong>Image Resource:</strong>
            ${resourceName}
          </p>

          <img
            src="${resourceUrl}"
            alt="${resourceName}"
            style="
              width:420px;
              max-width:100%;
              display:block;
              margin-top:12px;
              margin-bottom:12px;
              border-radius:8px;
            "
          />
        </div>
      `)
      .run();

    return;
  }

  if (isVideo) {
    editor
      .chain()
      .focus()
      .insertContent(`
        <p>
          <strong>Video Resource:</strong>
          <a href="${resourceUrl}">
            ${resourceName}
          </a>
        </p>
      `)
      .run();

    return;
  }

  editor
    .chain()
    .focus()
    .insertContent(`
      <p>
        <strong>Learning Resource:</strong>
        ${resourceName}
      </p>
    `)
    .run();
}

  function insertImageUrl() {

  const url = window.prompt("Paste image URL");

  if (!url) return;

  editor
    .chain()
    .focus()
    .setImage({
      src: url,
      width: 400
    })
    .run();
}

  function insertTable() {

    editor
      .chain()
      .focus()
      .insertTable({
        rows: 4,
        cols: 5,
        withHeaderRow: true
      })
      .run();
  }

  function insertPracticalActivity() {

    editor
      .chain()
      .focus()
      .insertContent(`
        <h3>Practical Activity</h3>

        <p><strong>Materials:</strong></p>

        <p><strong>Procedure:</strong></p>

        <p><strong>Observation:</strong></p>

        <p><strong>Conclusion:</strong></p>
      `)
      .run();
  }

  return (

    <div className="rich-editor">

      <div className="rich-toolbar">

        <button
          type="button"
          onClick={() =>
            editor.chain().focus().undo().run()
          }
        >
          Undo
        </button>

        <button
          type="button"
          onClick={() =>
            editor.chain().focus().redo().run()
          }
        >
          Redo
        </button>

        <button
          type="button"
          onClick={() =>
            editor.chain().focus().toggleBold().run()
          }
        >
          Bold
        </button>

        <button
          type="button"
          onClick={() =>
            editor.chain().focus().toggleItalic().run()
          }
        >
          Italic
        </button>

        <button
          type="button"
          onClick={() =>
            editor.chain().focus().toggleHeading({
              level: 2
            }).run()
          }
        >
          Heading
        </button>

        <button
          type="button"
          onClick={() =>
            editor.chain().focus().toggleBulletList().run()
          }
        >
          Bullets
        </button>

        <button
          type="button"
          onClick={() =>
            editor.chain().focus().toggleOrderedList().run()
          }
        >
          Numbering
        </button>

        <details className="insert-details">

          <summary>Insert ▾</summary>

          <button
            type="button"
            onClick={insertSelectedResource}
          >
            Selected Resource
          </button>

          <button
            type="button"
            onClick={insertImageUrl}
          >
            Image URL
          </button>

          <button
            type="button"
            onClick={insertTable}
          >
            Table
          </button>

          <button
            type="button"
            onClick={insertPracticalActivity}
          >
            Practical
          </button>

        </details>

      </div>

      <div
        style={{
          width: "100%",
          overflowX: "auto",
          overflowY: "auto",
          background: "#f9fafb"
        }}
      >

        <div
          style={{
            minWidth: "1800px",
            padding: "20px"
          }}
        >

          <EditorContent
            editor={editor}
            className="rich-editor-content"
          />

        </div>

      </div>

    </div>
  );
}