import useDependencyGraph from "../../hooks/useDependencyGraph";
import "./DependencyGraph.css";

export default function DependencyGraph() {

    const { graph } = useDependencyGraph();

    return (

        <div className="dependency-graph">

            <h3>

                AI Dependency Graph

            </h3>

            {

                Object.entries(graph).map(

                    ([workflow, nodes]) => (

                        <div

                            key={workflow}

                            className="graph-workflow"

                        >

                            <h4>

                                {workflow}

                            </h4>

                            <div className="graph-row">

                                {

                                    nodes.map(node => (

                                        <div

                                            key={node}

                                            className="graph-node"

                                        >

                                            {node}

                                        </div>

                                    ))

                                }

                            </div>

                        </div>

                    )

                )

            }

        </div>

    );

}