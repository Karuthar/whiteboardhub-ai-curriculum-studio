import useDependencyGraph from "../../hooks/useDependencyGraph";
import useWorkflowOptimizer from "../../hooks/useWorkflowOptimizer";

import "./WorkflowOptimizer.css";

export default function WorkflowOptimizer() {

    const graph = useDependencyGraph();

    const optimizer = useWorkflowOptimizer();

    return (

        <div className="workflow-optimizer">

            <h3>

                AI Workflow Optimizer

            </h3>

            {

                Object.keys(graph.graph).map(name => {

                    const optimized =

                        optimizer.optimize(

                            graph.getWorkflow(name)

                        );

                    return(

                        <div

                            key={name}

                            className="optimizer-block"

                        >

                            <strong>

                                {name}

                            </strong>

                            <div className="optimizer-row">

                                {

                                    optimized.map(stage=>(

                                        <span

                                            key={stage}

                                            className="optimizer-node"

                                        >

                                            {stage}

                                        </span>

                                    ))

                                }

                            </div>

                        </div>

                    );

                })

            }

        </div>

    );

}