import useWorkflowOrchestrator from "../../hooks/useWorkflowOrchestrator";

export default function WorkflowOrchestrator({
    orchestrator: providedOrchestrator
}) {

    const internalOrchestrator =
        useWorkflowOrchestrator();

    const orchestrator =
        providedOrchestrator ||
        internalOrchestrator;

    async function runWorkflow(workflow) {

        try {

            await orchestrator.execute(
                workflow
            );

        }

        catch (error) {

            console.error(
                "Workflow execution failed:",
                error
            );

        }

    }

    return (

        <div className="workflow-orchestrator">

            <h3>

                Universal Workflow Orchestrator

            </h3>

            <button

                type="button"

                disabled={
                    orchestrator.running
                }

                onClick={() =>
                    runWorkflow("documents")
                }

            >

                Run Documents Workflow

            </button>

            <button

                type="button"

                disabled={
                    orchestrator.running
                }

                onClick={() =>
                    runWorkflow("notes")
                }

            >

                Run Notes Workflow

            </button>

            <button

                type="button"

                disabled={
                    orchestrator.running
                }

                onClick={() =>
                    runWorkflow("assessment")
                }

            >

                Run Assessment Workflow

            </button>

        </div>

    );

}