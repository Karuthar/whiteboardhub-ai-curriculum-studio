import { useMemo, useState } from "react";

import useWorkflowTrace from "../../hooks/useWorkflowTrace";
import useWorkflowRecovery from "../../hooks/useWorkflowRecovery";

import "./WorkflowRecoveryDashboard.css";

export default function WorkflowRecoveryDashboard() {

    const { trace } = useWorkflowTrace();

    const {
        recover,
        recovering,
        getRecoveryStatus,
        getRetryCount,
        getRecoveryDecision
    } = useWorkflowRecovery();

    const [selectedWorkflow, setSelectedWorkflow] =
        useState("all");

    const workflows = useMemo(() => {

        return [
            ...new Set(
                trace
                    .map(entry => entry.workflow)
                    .filter(Boolean)
            )
        ];

    }, [trace]);

    const failures = useMemo(() => {

        const failed = trace.filter(
            entry =>
                entry.status === "Failed" ||
                entry.event === "workflow.failed" ||
                entry.event === "stage.failed"
        );

        if (selectedWorkflow === "all") {
            return [...failed].reverse();
        }

        return failed
            .filter(
                entry =>
                    entry.workflow === selectedWorkflow
            )
            .reverse();

    }, [trace, selectedWorkflow]);

    const recoverableCount = failures.filter(
        entry =>
            getRecoveryDecision(entry).allowed
    ).length;

    const manualCount = failures.filter(
        entry =>
            !getRecoveryDecision(entry).allowed
    ).length;

    const activeWorkflows = trace.filter(
        entry =>
            entry.status === "Running"
    );

    function formatTime(timestamp) {

        if (!timestamp) {
            return "—";
        }

        const date = new Date(timestamp);

        if (Number.isNaN(date.getTime())) {
            return timestamp;
        }

        return date.toLocaleString();

    }

    async function handleRecovery(entry) {

        await recover(entry);

    }

    return (

        <section className="workflow-recovery-dashboard">

            <div className="recovery-header">

                <div>

                    <h3>
                        AI Workflow Recovery
                    </h3>

                    <p>
                        Policy-controlled recovery and failure management.
                    </p>

                </div>

                <select
                    value={selectedWorkflow}
                    onChange={event =>
                        setSelectedWorkflow(
                            event.target.value
                        )
                    }
                >

                    <option value="all">
                        All Workflows
                    </option>

                    {workflows.map(workflow => (

                        <option
                            key={workflow}
                            value={workflow}
                        >
                            {workflow}
                        </option>

                    ))}

                </select>

            </div>

            <div className="recovery-summary">

                <div className="recovery-card">

                    <strong>
                        {failures.length}
                    </strong>

                    <span>
                        Failures
                    </span>

                </div>

                <div className="recovery-card">

                    <strong>
                        {recoverableCount}
                    </strong>

                    <span>
                        Auto Recoverable
                    </span>

                </div>

                <div className="recovery-card">

                    <strong>
                        {manualCount}
                    </strong>

                    <span>
                        Manual Review
                    </span>

                </div>

                <div className="recovery-card">

                    <strong>
                        {activeWorkflows.length}
                    </strong>

                    <span>
                        Running
                    </span>

                </div>

            </div>

            {!failures.length && (

                <div className="recovery-empty">

                    <h4>
                        No workflow failures detected
                    </h4>

                    <p>
                        WhiteBoard AI has no recorded failures requiring recovery.
                    </p>

                </div>

            )}

            {!!failures.length && (

                <div className="recovery-table-wrapper">

                    <table className="recovery-table">

                        <thead>

                            <tr>

                                <th>Time</th>
                                <th>Workflow</th>
                                <th>Event</th>
                                <th>Stage</th>
                                <th>Failure</th>
                                <th>Attempts</th>
                                <th>Policy</th>
                                <th>Action</th>

                            </tr>

                        </thead>

                        <tbody>

                            {failures.map(entry => {

                                const status =
                                    getRecoveryStatus(entry);

                                const attempts =
                                    getRetryCount(entry);

                                const decision =
                                    getRecoveryDecision(entry);

                                const disabled =
                                    recovering ||
                                    status === "Running" ||
                                    status === "Completed" ||
                                    status === "Manual" ||
                                    !decision.allowed;

                                return (

                                    <tr key={entry.id}>

                                        <td>
                                            {formatTime(
                                                entry.timestamp
                                            )}
                                        </td>

                                        <td>
                                            <strong>
                                                {entry.workflow}
                                            </strong>
                                        </td>

                                        <td>
                                            {entry.event || "—"}
                                        </td>

                                        <td>
                                            {entry.stage || "—"}
                                        </td>

                                        <td className="recovery-error">

                                            {entry.message ||
                                                entry.metadata?.error ||
                                                "Unknown failure"}

                                        </td>

                                        <td>
                                            {attempts}
                                        </td>

                                        <td>

                                            <span
                                                className={
                                                    decision.allowed
                                                        ? "policy-allowed"
                                                        : "policy-blocked"
                                                }
                                            >

                                                {
                                                    decision.allowed
                                                        ? "Allowed"
                                                        : "Manual"
                                                }

                                            </span>

                                        </td>

                                        <td>

                                            <button
                                                type="button"
                                                disabled={disabled}
                                                onClick={() =>
                                                    handleRecovery(entry)
                                                }
                                            >

                                                {

                                                    status === "Running"
                                                        ? "Recovering..."
                                                        : status === "Completed"
                                                        ? "Recovered"
                                                        : status === "Manual"
                                                        ? "Manual Review"
                                                        : decision.allowed
                                                        ? "Recover"
                                                        : "Blocked"

                                                }

                                            </button>

                                        </td>

                                    </tr>

                                );

                            })}

                        </tbody>

                    </table>

                </div>

            )}

        </section>

    );

}