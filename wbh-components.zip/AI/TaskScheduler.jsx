import "./TaskScheduler.css";

export default function TaskScheduler({ queue }) {

    return (

        <div className="task-scheduler">

            <h3>AI Task Scheduler</h3>

            {

                queue.length === 0 &&

                <p>No scheduled tasks.</p>

            }

            {

                queue.map(job => (

                    <div

                        key={job.id}

                        className="task-item"

                    >

                        <strong>{job.task}</strong>

                        <span>{job.status}</span>

                    </div>

                ))

            }

        </div>

    );

}