import useRecoveryPolicyAnalytics
    from "../../hooks/useRecoveryPolicyAnalytics";

import "./RecoveryPolicyAnalytics.css";

export default function RecoveryPolicyAnalytics() {

    const {
        events,
        analytics,
        clear
    } = useRecoveryPolicyAnalytics();

    return (

        <div className="recovery-policy-analytics">

            <div className="recovery-policy-analytics-header">

                <div>

                    <h3>
                        Recovery Policy Analytics
                    </h3>

                    <p>
                        Recovery outcomes, policy decisions,
                        retry effectiveness and learning signals.
                    </p>

                </div>

                <button
                    type="button"
                    onClick={clear}
                    disabled={!events.length}
                >
                    Clear Analytics
                </button>

            </div>

            <div className="recovery-analytics-summary">

                <div className="recovery-analytics-card">
                    <span>Total Events</span>
                    <strong>{analytics.total}</strong>
                </div>

                <div className="recovery-analytics-card">
                    <span>Recovery Rate</span>
                    <strong>
                        {analytics.recoveryRate}%
                    </strong>
                </div>

                <div className="recovery-analytics-card">
                    <span>Successful</span>
                    <strong>
                        {analytics.successful}
                    </strong>
                </div>

                <div className="recovery-analytics-card">
                    <span>Failed</span>
                    <strong>
                        {analytics.failed}
                    </strong>
                </div>

                <div className="recovery-analytics-card">
                    <span>Blocked</span>
                    <strong>
                        {analytics.blocked}
                    </strong>
                </div>

                <div className="recovery-analytics-card">
                    <span>Manual Intervention</span>
                    <strong>
                        {analytics.manual}
                    </strong>
                </div>

                <div className="recovery-analytics-card">
                    <span>Retry Decisions</span>
                    <strong>
                        {analytics.retryable}
                    </strong>
                </div>

                <div className="recovery-analytics-card">
                    <span>Average Attempts</span>
                    <strong>
                        {analytics.averageAttempts}
                    </strong>
                </div>

            </div>

            <div className="recovery-analytics-section">

                <h4>
                    Recovery Events
                </h4>

                {!events.length && (

                    <p className="recovery-analytics-empty">
                        No recovery analytics recorded yet.
                    </p>

                )}

                {events.length > 0 && (

                    <div className="recovery-analytics-table-wrapper">

                        <table className="recovery-analytics-table">

                            <thead>

                                <tr>

                                    <th>Time</th>
                                    <th>Workflow</th>
                                    <th>Stage</th>
                                    <th>Policy</th>
                                    <th>Decision</th>
                                    <th>Status</th>
                                    <th>Attempts</th>
                                    <th>Outcome</th>

                                </tr>

                            </thead>

                            <tbody>

                                {events.map(event => (

                                    <tr key={event.id}>

                                        <td>
                                            {new Date(
                                                event.timestamp
                                            ).toLocaleString()}
                                        </td>

                                        <td>
                                            {event.workflow}
                                        </td>

                                        <td>
                                            {event.stage}
                                        </td>

                                        <td>
                                            {event.policy}
                                        </td>

                                        <td>
                                            {event.decision}
                                        </td>

                                        <td>
                                            {event.status}
                                        </td>

                                        <td>
                                            {event.attempts}
                                        </td>

                                        <td>
                                            {event.outcome}
                                        </td>

                                    </tr>

                                ))}

                            </tbody>

                        </table>

                    </div>

                )}

            </div>

        </div>

    );

}