import { useState } from "react";

import useAiPipeline from "../../hooks/useAiPipeline";
import useActivityCenter from "../../hooks/useActivityCenter";
import useNotifications from "../../hooks/useNotifications";
import useTaskScheduler from "../../hooks/useTaskScheduler";
import useWorkflowOrchestrator from "../../hooks/useWorkflowOrchestrator";

import PipelineMonitor from "./PipelineMonitor";
import ActivityCenter from "./ActivityCenter";
import NotificationCenter from "./NotificationCenter";
import TaskScheduler from "./TaskScheduler";
import DependencyGraph from "./DependencyGraph";
import WorkflowOptimizer from "./WorkflowOptimizer";
import ExecutionEngine from "./ExecutionEngine";
import WorkflowOrchestrator from "./WorkflowOrchestrator";
import WorkflowTraceViewer from "./WorkflowTraceViewer";
import WorkflowRecoveryDashboard from "./WorkflowRecoveryDashboard";
import RecoveryPolicyAnalytics from "./RecoveryPolicyAnalytics";

import "./AICommandCenter.css";

export default function AICommandCenter() {

    const pipeline = useAiPipeline();
    const activity = useActivityCenter();
    const notifications = useNotifications();
    const scheduler = useTaskScheduler();
    const orchestrator = useWorkflowOrchestrator();

    const [running, setRunning] = useState(false);

    async function execute(task) {

        notifications.notify(
            "Starting " + task + "...",
            "info"
        );

        activity.log(
            "Started " + task,
            "Running"
        );

        try {

            setRunning(true);

            const result = await new Promise(
                (resolve, reject) => {

                    scheduler.schedule(
                        task,
                        async () => {

                            try {

                                const workflowResult =
                                    await orchestrator.execute(task);

                                if (
                                    !workflowResult?.success
                                ) {

                                    reject(
                                        workflowResult?.error ||
                                        new Error(
                                            `${task} workflow failed`
                                        )
                                    );

                                    return;
                                }

                                resolve(
                                    workflowResult
                                );

                            }

                            catch (error) {

                                reject(error);

                            }

                        }
                    );

                }
            );

            activity.log(
                "Finished " + task,
                "Completed"
            );

            notifications.notify(
                task + " completed.",
                "success"
            );

            return result;

        }

        catch (error) {

            console.error(
                "AI command failed:",
                error
            );

            activity.log(
                "Failed " + task,
                "Failed"
            );

            notifications.notify(
                task + " failed.",
                "error"
            );

            return null;

        }

        finally {

            setRunning(false);

        }

    }

    return (

        <>

            <NotificationCenter
                notifications={
                    notifications.notifications
                }
                onDismiss={
                    notifications.dismiss
                }
            />

            <div className="ai-command-center">

                <h3>
                    AI Workflow Engine
                </h3>

                <PipelineMonitor

                    running={
                        pipeline.running
                    }

                    stage={
                        pipeline.stage
                    }

                    progress={
                        pipeline.progress
                    }

                />

                <ActivityCenter

                    activities={
                        activity.activities
                    }

                />

                <TaskScheduler

                    queue={
                        scheduler.queue
                    }

                />

                <WorkflowOrchestrator
                    orchestrator={
                        orchestrator
                    }
                />

                <DependencyGraph />

                <WorkflowOptimizer />

                <ExecutionEngine

                    running={
                        orchestrator.running
                    }

                    currentStage={
                        orchestrator.currentStage
                    }

                />

                <p>

                    Select what you want WhiteBoard AI
                    to produce.

                </p>

                <div className="workflow-buttons">

                    <button

                        disabled={running}

                        onClick={() =>
                            execute("documents")
                        }

                    >

                        Generate Professional Documents

                    </button>

                    <button

                        disabled={running}

                        onClick={() =>
                            execute("notes")
                        }

                    >

                        Generate Notes / Revision Resources

                    </button>

                    <button

                        disabled={running}

                        onClick={() =>
                            execute("assessment")
                        }

                    >

                        Generate Assessment Items

                    </button>

                </div>

                {running && (

                    <p className="pipeline-status">

                        WhiteBoard AI is building
                        your workflow...

                    </p>

                )}

                <WorkflowTraceViewer />

                <WorkflowRecoveryDashboard />

                <RecoveryPolicyAnalytics />

            </div>

        </>

    );

}