import "./ExecutionEngine.css";

export default function ExecutionEngine({

    running,

    currentStage

}){

    return(

        <div className="execution-engine">

            <h3>

                Universal AI Execution Engine

            </h3>

            <p>

                Status:

                <strong>

                    {

                        running

                        ? " Running"

                        : " Idle"

                    }

                </strong>

            </p>

            {

                running &&

                <div className="execution-stage">

                    Executing:

                    <strong>

                        {currentStage}

                    </strong>

                </div>

            }

        </div>

    );

}