import "./PipelineMonitor.css";

export default function PipelineMonitor({

    stage,

    progress,

    running

}){

    const steps=[

        "Curriculum Ready",

        "Scheme Generated",

        "Lesson Plan",

        "Learning Experiences",

        "Lesson Notes",

        "Assessment",

        "Completed"

    ];

    return(

        <div className="pipeline-monitor">

            <h3>AI Pipeline Monitor</h3>

            <div className="pipeline-progress">

                <div

                    className="pipeline-bar"

                    style={{

                        width:`${progress}%`

                    }}

                />

            </div>

            <p>

                {

                    running

                    ?

                    `Processing : ${steps[stage]}`

                    :

                    "Idle"

                }

            </p>

            <ul>

                {

                    steps.map((s,index)=>(

                        <li

                            key={index}

                            className={

                                index<=stage

                                ?

                                "done"

                                :

                                ""

                            }

                        >

                            {index<=stage?"✓ ":"○ "}

                            {s}

                        </li>

                    ))

                }

            </ul>

        </div>

    );

}