import "./NotificationCenter.css";

export default function NotificationCenter({
    notifications = [],
    onDismiss
}) {

    if (!notifications.length) {

        return null;

    }

    return (

        <div className="notification-center">

            {notifications.map(
                notification => (

                    <div
                        key={notification.id}
                        className={
                            `notification ${
                                notification.type || "info"
                            }`
                        }
                    >

                        <span className="notification-message">

                            {notification.message}

                        </span>

                        {onDismiss && (

                            <button

                                type="button"

                                className="notification-dismiss"

                                aria-label="Dismiss notification"

                                onClick={() =>
                                    onDismiss(
                                        notification.id
                                    )
                                }

                            >

                                ×

                            </button>

                        )}

                    </div>

                )
            )}

        </div>

    );

}