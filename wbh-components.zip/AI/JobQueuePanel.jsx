import "./JobQueuePanel.css";

export default function JobQueuePanel({ jobs }) {

    return (

        <div className="jobqueue-panel">

            <h3>AI Job Queue</h3>

            {

                jobs.length===0

                &&

                <p>No active jobs.</p>

            }

            {

                jobs.map(job=>(

                    <div
                        key={job.id}
                        className="job-card"
                    >

                        <strong>{job.title}</strong>

                        <div>{job.status}</div>

                    </div>

                ))

            }

        </div>

    );

}