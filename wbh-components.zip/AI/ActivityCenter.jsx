import "./ActivityCenter.css";

export default function ActivityCenter({ activities = [] }) {

    return (

        <div className="activity-center">

            <h3>AI Activity Center</h3>

            {

                activities.length === 0 &&

                <p>No activity yet.</p>

            }

            {

                activities.map(item => (

                    <div

                        key={item.id}

                        className="activity-item"

                    >

                        <strong>{item.title}</strong>

                        <div>{item.time}</div>

                        <small>{item.status}</small>

                    </div>

                ))

            }

        </div>

    );

}