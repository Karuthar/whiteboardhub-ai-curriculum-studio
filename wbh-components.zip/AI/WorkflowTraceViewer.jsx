import { useMemo, useState } from "react";
import useWorkflowTrace from "../../hooks/useWorkflowTrace";
import "./WorkflowTraceViewer.css";

export default function WorkflowTraceViewer() {

    const {
        trace,
        clear,
        getWorkflowTrace
    } = useWorkflowTrace();

    const [selectedWorkflow, setSelectedWorkflow] = useState("all");

    const workflows = useMemo(() => {

        return [
            ...new Set(
                trace
                    .map(entry => entry.workflow)
                    .filter(Boolean)
            )
        ];

    }, [trace]);

    const visibleTrace = useMemo(() => {

        if (selectedWorkflow === "all") {
            return [...trace].reverse();
        }

        return [
            ...getWorkflowTrace(selectedWorkflow)
        ].reverse();

    }, [
        trace,
        selectedWorkflow,
        getWorkflowTrace
    ]);

    function formatTimestamp(timestamp) {

        if (!timestamp) {
            return "—";
        }

        const date = new Date(timestamp);

        if (Number.isNaN(date.getTime())) {
            return timestamp;
        }

        return date.toLocaleString();

    }

    function statusClass(status) {

        return String(status || "Info")
            .toLowerCase()
            .replace(/\s+/g, "-");

    }

    function clearTrace() {

        const confirmed = window.confirm(
            "Clear the complete workflow audit trail?"
        );

        if (confirmed) {
            clear();
        }

    }

    return (

        <section className="workflow-trace-viewer">

            <div className="workflow-trace-header">

                <div>

                    <h3>
                        Workflow Audit Trail
                    </h3>

                    <p>
                        Complete execution history for WhiteBoard AI workflows.
                    </p>

                </div>

                <div className="workflow-trace-controls">

                    <select
                        value={selectedWorkflow}
                        onChange={event =>
                            setSelectedWorkflow(event.target.value)
                        }
                    >

                        <option value="all">
                            All Workflows
                        </option>

                        {workflows.map(workflow => (

                            <option
                                key={workflow}
                                value={workflow}
                            >
                                {workflow}
                            </option>

                        ))}

                    </select>

                    <button
                        type="button"
                        onClick={clearTrace}
                        disabled={!trace.length}
                    >
                        Clear Audit Trail
                    </button>

                </div>

            </div>

            <div className="workflow-trace-summary">

                <div className="trace-stat">

                    <strong>
                        {trace.length}
                    </strong>

                    <span>
                        Events
                    </span>

                </div>

                <div className="trace-stat">

                    <strong>
                        {
                            trace.filter(
                                entry =>
                                    entry.status === "Completed"
                            ).length
                        }
                    </strong>

                    <span>
                        Completed
                    </span>

                </div>

                <div className="trace-stat">

                    <strong>
                        {
                            trace.filter(
                                entry =>
                                    entry.status === "Failed"
                            ).length
                        }
                    </strong>

                    <span>
                        Failed
                    </span>

                </div>

                <div className="trace-stat">

                    <strong>
                        {
                            trace.filter(
                                entry =>
                                    entry.status === "Running"
                            ).length
                        }
                    </strong>

                    <span>
                        Running
                    </span>

                </div>

            </div>

            {!visibleTrace.length && (

                <div className="workflow-trace-empty">

                    <h4>
                        No workflow events recorded
                    </h4>

                    <p>
                        Workflow execution events will appear here automatically.
                    </p>

                </div>

            )}

            {!!visibleTrace.length && (

                <div className="workflow-trace-table-wrapper">

                    <table className="workflow-trace-table">

                        <thead>

                            <tr>

                                <th>
                                    Time
                                </th>

                                <th>
                                    Workflow
                                </th>

                                <th>
                                    Event
                                </th>

                                <th>
                                    Stage
                                </th>

                                <th>
                                    Status
                                </th>

                                <th>
                                    Message
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                            {visibleTrace.map(entry => (

                                <tr key={entry.id}>

                                    <td>
                                        {formatTimestamp(entry.timestamp)}
                                    </td>

                                    <td>
                                        <strong>
                                            {entry.workflow}
                                        </strong>
                                    </td>

                                    <td>
                                        {entry.event}
                                    </td>

                                    <td>
                                        {entry.stage || "—"}
                                    </td>

                                    <td>

                                        <span
                                            className={
                                                `workflow-trace-status ${statusClass(entry.status)}`
                                            }
                                        >
                                            {entry.status || "Info"}
                                        </span>

                                    </td>

                                    <td>
                                        {entry.message || "—"}
                                    </td>

                                </tr>

                            ))}

                        </tbody>

                    </table>

                </div>

            )}

        </section>

    );

}