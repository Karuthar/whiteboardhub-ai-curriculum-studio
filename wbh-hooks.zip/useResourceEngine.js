export default function useResourceEngine(studio){

    async function uploadLearningResources(){}

    function insertSelectedResource(){}

    function renderResourceSidePreview(){

        return null;

    }

    return{

        uploadLearningResources,

        insertSelectedResource,

        renderResourceSidePreview

    };

}S