export default function useWorkflowOptimizer() {

    function optimize(workflow) {

        const stages = [...workflow];

        const optimized = [];

        const completed = new Set();

        stages.forEach(stage => {

            if (!completed.has(stage)) {

                optimized.push(stage);

                completed.add(stage);

            }

        });

        return optimized;

    }

    return {

        optimize

    };

}