export default function useAIEngine(studio){

    async function uploadCurriculum(){}

    async function parseCurriculum(){}

    async function generateScheme(){}

    return{

        uploadCurriculum,

        parseCurriculum,

        generateScheme

    };

}