import { useCallback, useMemo, useState } from "react";

const STORAGE_KEY = "whiteboardhub_recovery_policy_analytics";

function loadEvents() {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);

        if (!stored) {
            return [];
        }

        const parsed = JSON.parse(stored);

        return Array.isArray(parsed) ? parsed : [];
    }
    catch (error) {
        console.error(
            "Unable to load recovery policy analytics.",
            error
        );

        return [];
    }
}

function saveEvents(events) {
    try {
        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(events)
        );
    }
    catch (error) {
        console.error(
            "Unable to save recovery policy analytics.",
            error
        );
    }
}

export default function useRecoveryPolicyAnalytics() {

    const [events, setEvents] = useState(loadEvents);

    const record = useCallback((event = {}) => {

        const entry = {
            id:
                event.id ||
                `${Date.now()}-${Math.random()
                    .toString(36)
                    .slice(2, 9)}`,

            timestamp:
                event.timestamp ||
                new Date().toISOString(),

            workflow:
                event.workflow ||
                "Unknown workflow",

            stage:
                event.stage ||
                "Unknown stage",

            policy:
                event.policy ||
                "Unknown policy",

            decision:
                event.decision ||
                "Unknown",

            status:
                event.status ||
                "Unknown",

            attempts:
                Number(event.attempts || 0),

            outcome:
                event.outcome ||
                "Unknown",

            reason:
                event.reason ||
                ""
        };

        setEvents(previous => {

            const next = [
                entry,
                ...previous
            ].slice(0, 500);

            saveEvents(next);

            return next;

        });

        return entry;

    }, []);

    const clear = useCallback(() => {

        setEvents([]);

        try {
            localStorage.removeItem(STORAGE_KEY);
        }
        catch (error) {
            console.error(
                "Unable to clear recovery policy analytics.",
                error
            );
        }

    }, []);

    const analytics = useMemo(() => {

        const total = events.length;

        const successful =
            events.filter(
                event =>
                    event.outcome === "Recovered" ||
                    event.outcome === "Completed" ||
                    event.status === "Completed"
            ).length;

        const failed =
            events.filter(
                event =>
                    event.outcome === "Failed" ||
                    event.status === "Failed"
            ).length;

        const blocked =
            events.filter(
                event =>
                    event.decision === "Blocked" ||
                    event.status === "Blocked"
            ).length;

        const manual =
            events.filter(
                event =>
                    event.decision === "Manual Intervention"
            ).length;

        const retryable =
            events.filter(
                event =>
                    event.decision === "Retry"
            ).length;

        const recoveryRate =
            total > 0
                ? Math.round(
                    (successful / total) * 100
                )
                : 0;

        const averageAttempts =
            total > 0
                ? Number(
                    (
                        events.reduce(
                            (sum, event) =>
                                sum +
                                Number(event.attempts || 0),
                            0
                        ) / total
                    ).toFixed(2)
                )
                : 0;

        const policyCounts = {};

        events.forEach(event => {

            const policy =
                event.policy || "Unknown";

            policyCounts[policy] =
                (policyCounts[policy] || 0) + 1;

        });

        const outcomeCounts = {};

        events.forEach(event => {

            const outcome =
                event.outcome || "Unknown";

            outcomeCounts[outcome] =
                (outcomeCounts[outcome] || 0) + 1;

        });

        return {
            total,
            successful,
            failed,
            blocked,
            manual,
            retryable,
            recoveryRate,
            averageAttempts,
            policyCounts,
            outcomeCounts
        };

    }, [events]);

    return {
        events,
        analytics,
        record,
        clear
    };

}