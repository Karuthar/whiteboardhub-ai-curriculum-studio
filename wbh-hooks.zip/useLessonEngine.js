export default function useLessonEngine(studio){

    async function generateLessonPlan(){}

    async function generateLessonPackage(){}

    async function generateRecordOfWork(){}

    return{

        generateLessonPlan,

        generateLessonPackage,

        generateRecordOfWork

    };

}s