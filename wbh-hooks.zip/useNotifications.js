import { useCallback, useState } from "react";

export default function useNotifications() {
    const [notifications, setNotifications] = useState([]);

    const notify = useCallback((message, type = "info") => {
        const notification = {
            id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            message,
            type,
            timestamp: new Date().toISOString()
        };

        setNotifications(previous => [
            ...previous,
            notification
        ]);

        return notification;
    }, []);

    const dismiss = useCallback((id) => {
        setNotifications(previous =>
            previous.filter(notification => notification.id !== id)
        );
    }, []);

    const clear = useCallback(() => {
        setNotifications([]);
    }, []);

    return {
        notifications,
        notify,
        dismiss,
        clear
    };
}
