import { useState } from "react";

export default function useActivityCenter(){

    const [activities,setActivities]=useState([]);

    function log(title,status="Completed"){

        setActivities(prev=>([

            {

                id:Date.now(),

                title,

                status,

                time:new Date().toLocaleTimeString()

            },

            ...prev

        ]));

    }

    return{

        activities,

        log

    };

}