import { useCallback, useEffect, useState } from "react";

const STORAGE_KEY = "whiteboardhub.workflowTrace";
const MAX_ENTRIES = 500;

function createId() {
    return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function loadTrace() {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);

        if (!stored) {
            return [];
        }

        const parsed = JSON.parse(stored);

        return Array.isArray(parsed) ? parsed : [];
    }
    catch (error) {
        console.error("Workflow trace load failed:", error);
        return [];
    }
}

function persistTrace(entries) {
    try {
        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(entries.slice(-MAX_ENTRIES))
        );
    }
    catch (error) {
        console.error("Workflow trace save failed:", error);
    }
}

export default function useWorkflowTrace() {

    const [trace, setTrace] = useState(loadTrace);

    useEffect(() => {
        persistTrace(trace);
    }, [trace]);

    const record = useCallback(
        ({
            workflow,
            event,
            status = "Info",
            stage = null,
            task = null,
            message = "",
            metadata = {}
        }) => {

            const entry = {
                id: createId(),
                timestamp: new Date().toISOString(),
                workflow: workflow || "unknown",
                event,
                status,
                stage,
                task,
                message,
                metadata
            };

            setTrace(previous => {

                const next = [
                    ...previous,
                    entry
                ];

                return next.slice(-MAX_ENTRIES);

            });

            return entry;
        },
        []
    );

    const start = useCallback(
        (workflow, metadata = {}) =>
            record({
                workflow,
                event: "workflow.started",
                status: "Running",
                message: `${workflow} workflow started`,
                metadata
            }),
        [record]
    );

    const stageStart = useCallback(
        (workflow, stage, metadata = {}) =>
            record({
                workflow,
                event: "stage.started",
                status: "Running",
                stage,
                message: `Stage ${stage} started`,
                metadata
            }),
        [record]
    );

    const stageComplete = useCallback(
        (workflow, stage, metadata = {}) =>
            record({
                workflow,
                event: "stage.completed",
                status: "Completed",
                stage,
                message: `Stage ${stage} completed`,
                metadata
            }),
        [record]
    );

    const complete = useCallback(
        (workflow, metadata = {}) =>
            record({
                workflow,
                event: "workflow.completed",
                status: "Completed",
                message: `${workflow} workflow completed`,
                metadata
            }),
        [record]
    );

    const fail = useCallback(
        (workflow, error, metadata = {}) =>
            record({
                workflow,
                event: "workflow.failed",
                status: "Failed",
                message:
                    error?.message ||
                    `${workflow} workflow failed`,
                metadata: {
                    ...metadata,
                    error: error?.message || String(error)
                }
            }),
        [record]
    );

    const clear = useCallback(() => {
        setTrace([]);
        localStorage.removeItem(STORAGE_KEY);
    }, []);

    const getWorkflowTrace = useCallback(
        workflow => {

            if (!workflow) {
                return trace;
            }

            return trace.filter(
                entry => entry.workflow === workflow
            );

        },
        [trace]
    );

    return {
        trace,
        record,
        start,
        stageStart,
        stageComplete,
        complete,
        fail,
        clear,
        getWorkflowTrace
    };
}