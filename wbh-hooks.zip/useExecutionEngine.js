import { useState } from "react";

export default function useExecutionEngine() {

    const [running,setRunning]=useState(false);

    const [currentStage,setCurrentStage]=useState("");

    async function execute(stages,runner){

        setRunning(true);

        try{

            for(const stage of stages){

                setCurrentStage(stage);

                await runner(stage);

            }

        }

        finally{

            setCurrentStage("");

            setRunning(false);

        }

    }

    return{

        running,

        currentStage,

        execute

    };

}