export default function useDependencyGraph() {

    const graph = {

        documents: [

            "curriculum",

            "scheme",

            "lessonPlan",

            "learningActivities",

            "lessonNotes",

            "assessment",

            "recordOfWork"

        ],

        notes: [

            "curriculum",

            "scheme",

            "lessonPlan",

            "lessonNotes"

        ],

        assessment: [

            "curriculum",

            "scheme",

            "lessonPlan",

            "assessment"

        ]

    };

    function getWorkflow(name) {

        return graph[name] || [];

    }

    return {

        graph,

        getWorkflow

    };

}