import { useState } from "react";

export default function useSelfHealingEngine() {

    const [recovering, setRecovering] = useState(false);
    const [recoveryStage, setRecoveryStage] = useState("");
    const [recoveryAttempts, setRecoveryAttempts] = useState(0);

    async function executeWithRecovery(
        stage,
        runner,
        options = {}
    ) {

        const maxRetries =
            Number.isInteger(options.maxRetries)
                ? options.maxRetries
                : 2;

        let attempt = 0;

        while (attempt <= maxRetries) {

            try {

                setRecoveryStage(stage);
                setRecoveryAttempts(attempt);

                const result = await runner();

                setRecoveryStage("");
                setRecoveryAttempts(0);

                return result;

            }

            catch (error) {

                attempt += 1;

                if (attempt > maxRetries) {

                    setRecoveryStage("");
                    setRecoveryAttempts(0);

                    throw error;

                }

                setRecovering(true);

                setRecoveryStage(
                    `Recovering ${stage}...`
                );

                setRecoveryAttempts(attempt);

                await new Promise(resolve =>
                    setTimeout(
                        resolve,
                        500 * attempt
                    )
                );

                setRecovering(false);

            }

        }

    }

    return {

        recovering,
        recoveryStage,
        recoveryAttempts,
        executeWithRecovery

    };

}