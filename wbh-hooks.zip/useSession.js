import { useMemo } from "react";
import { useStudioContext } from "../contexts/StudioContext";

export default function useSession() {

    const studio = useStudioContext();

    return useMemo(() => ({

        accessMode: studio.accessMode,

        workflow: studio.workflow,

        curriculum: studio.curriculum,

        curriculumReady: studio.curriculumReady,

        user: studio.user || null,

        guest: studio.accessMode === "guest",

        member: studio.accessMode === "member"

    }), [studio]);

}