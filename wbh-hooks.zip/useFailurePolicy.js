import { useCallback, useState } from "react";

const FAILURE_TYPES = {
    NETWORK: "network",
    AUTHENTICATION: "authentication",
    VALIDATION: "validation",
    NOT_FOUND: "not_found",
    SERVER: "server",
    TIMEOUT: "timeout",
    RATE_LIMIT: "rate_limit",
    DEPENDENCY: "dependency",
    UNKNOWN: "unknown"
};

const RECOVERY_ACTIONS = {
    RETRY: "retry",
    REFRESH: "refresh",
    REAUTHENTICATE: "reauthenticate",
    SKIP: "skip",
    REBUILD_DEPENDENCY: "rebuild_dependency",
    STOP: "stop"
};

function classifyError(error) {

    const status =
        error?.response?.status ??
        error?.status ??
        error?.statusCode;

    const code =
        error?.code ||
        error?.response?.data?.code ||
        "";

    const message =
        error?.response?.data?.message ||
        error?.message ||
        String(error || "Unknown error");

    const normalized = message.toLowerCase();

    if (
        status === 401 ||
        status === 403 ||
        normalized.includes("unauthorized") ||
        normalized.includes("authentication")
    ) {
        return FAILURE_TYPES.AUTHENTICATION;
    }

    if (
        status === 404 ||
        normalized.includes("not found")
    ) {
        return FAILURE_TYPES.NOT_FOUND;
    }

    if (
        status === 400 ||
        status === 422 ||
        normalized.includes("validation")
    ) {
        return FAILURE_TYPES.VALIDATION;
    }

    if (
        status === 429 ||
        normalized.includes("rate limit") ||
        normalized.includes("too many requests")
    ) {
        return FAILURE_TYPES.RATE_LIMIT;
    }

    if (
        code === "ECONNABORTED" ||
        code === "ETIMEDOUT" ||
        normalized.includes("timeout")
    ) {
        return FAILURE_TYPES.TIMEOUT;
    }

    if (
        normalized.includes("dependency") ||
        normalized.includes("prerequisite")
    ) {
        return FAILURE_TYPES.DEPENDENCY;
    }

    if (
        !status &&
        (
            normalized.includes("network") ||
            normalized.includes("fetch failed") ||
            normalized.includes("failed to fetch") ||
            normalized.includes("connection")
        )
    ) {
        return FAILURE_TYPES.NETWORK;
    }

    if (status >= 500) {
        return FAILURE_TYPES.SERVER;
    }

    return FAILURE_TYPES.UNKNOWN;
}

function getRecoveryPolicy(type) {

    switch (type) {

        case FAILURE_TYPES.NETWORK:
            return {
                action: RECOVERY_ACTIONS.RETRY,
                maxAttempts: 3,
                retryDelay: 1500,
                recoverable: true
            };

        case FAILURE_TYPES.TIMEOUT:
            return {
                action: RECOVERY_ACTIONS.RETRY,
                maxAttempts: 2,
                retryDelay: 2000,
                recoverable: true
            };

        case FAILURE_TYPES.RATE_LIMIT:
            return {
                action: RECOVERY_ACTIONS.RETRY,
                maxAttempts: 2,
                retryDelay: 5000,
                recoverable: true
            };

        case FAILURE_TYPES.AUTHENTICATION:
            return {
                action: RECOVERY_ACTIONS.REAUTHENTICATE,
                maxAttempts: 1,
                retryDelay: 0,
                recoverable: true
            };

        case FAILURE_TYPES.NOT_FOUND:
            return {
                action: RECOVERY_ACTIONS.REFRESH,
                maxAttempts: 1,
                retryDelay: 500,
                recoverable: true
            };

        case FAILURE_TYPES.DEPENDENCY:
            return {
                action: RECOVERY_ACTIONS.REBUILD_DEPENDENCY,
                maxAttempts: 1,
                retryDelay: 500,
                recoverable: true
            };

        case FAILURE_TYPES.VALIDATION:
            return {
                action: RECOVERY_ACTIONS.STOP,
                maxAttempts: 0,
                retryDelay: 0,
                recoverable: false
            };

        case FAILURE_TYPES.SERVER:
            return {
                action: RECOVERY_ACTIONS.RETRY,
                maxAttempts: 2,
                retryDelay: 3000,
                recoverable: true
            };

        default:
            return {
                action: RECOVERY_ACTIONS.STOP,
                maxAttempts: 0,
                retryDelay: 0,
                recoverable: false
            };

    }

}

export default function useFailurePolicy() {

    const [failures, setFailures] = useState([]);

    const analyze = useCallback(
        (error, context = {}) => {

            const type = classifyError(error);
            const policy = getRecoveryPolicy(type);

            const failure = {
                id:
                    `${Date.now()}-${Math.random()
                        .toString(36)
                        .slice(2, 8)}`,

                type,

                policy,

                message:
                    error?.response?.data?.message ||
                    error?.message ||
                    String(error || "Unknown error"),

                context,

                timestamp:
                    new Date().toISOString()
            };

            setFailures(previous => [
                ...previous,
                failure
            ]);

            return failure;

        },
        []
    );

    const getPolicy = useCallback(
        error => {

            const type = classifyError(error);

            return {
                type,
                ...getRecoveryPolicy(type)
            };

        },
        []
    );

    const shouldRetry = useCallback(
        (error, attempt = 0) => {

            const policy = getPolicy(error);

            return (
                policy.recoverable &&
                policy.action === RECOVERY_ACTIONS.RETRY &&
                attempt < policy.maxAttempts
            );

        },
        [getPolicy]
    );

    const getRetryDelay = useCallback(
        error => {

            return getPolicy(error).retryDelay;

        },
        [getPolicy]
    );

    const clearFailures = useCallback(() => {

        setFailures([]);

    }, []);

    return {

        failures,

        analyze,
        getPolicy,
        shouldRetry,
        getRetryDelay,
        clearFailures,

        FAILURE_TYPES,
        RECOVERY_ACTIONS

    };

}