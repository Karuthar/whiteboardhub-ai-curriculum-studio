import { useMemo } from "react";

const DEFAULT_POLICY = {
    maxRetries: 3,
    retryableEvents: [
        "stage.failed",
        "workflow.failed"
    ],
    retryableStatuses: [
        "Failed"
    ],
    manualInterventionEvents: [
        "policy.blocked",
        "security.failure",
        "authorization.failure"
    ]
};

export default function useRecoveryPolicy(customPolicy = {}) {

    const policy = useMemo(() => ({
        ...DEFAULT_POLICY,
        ...customPolicy
    }), [customPolicy]);

    function evaluate(entry, retryCount = 0) {

        if (!entry) {

            return {
                allowed: false,
                action: "manual",
                reason: "No failure record supplied."
            };

        }

        if (
            policy.manualInterventionEvents.includes(
                entry.event
            )
        ) {

            return {
                allowed: false,
                action: "manual",
                reason: "Manual intervention is required."
            };

        }

        const eventAllowed =
            policy.retryableEvents.includes(
                entry.event
            );

        const statusAllowed =
            !entry.status ||
            policy.retryableStatuses.includes(
                entry.status
            );

        if (!eventAllowed || !statusAllowed) {

            return {
                allowed: false,
                action: "manual",
                reason: "Failure type is not automatically retryable."
            };

        }

        if (retryCount >= policy.maxRetries) {

            return {
                allowed: false,
                action: "manual",
                reason: "Maximum recovery attempts reached."
            };

        }

        return {
            allowed: true,
            action: "retry",
            reason: "Failure is eligible for automatic recovery.",
            remainingRetries:
                policy.maxRetries - retryCount
        };

    }

    return {
        policy,
        evaluate
    };

}