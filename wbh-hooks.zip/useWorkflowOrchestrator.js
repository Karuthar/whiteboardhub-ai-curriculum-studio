import useAiPipeline from "./useAiPipeline";
import useNotifications from "./useNotifications";
import useActivityCenter from "./useActivityCenter";
import useExecutionEngine from "./useExecutionEngine";
import useDependencyGraph from "./useDependencyGraph";
import useWorkflowOptimizer from "./useWorkflowOptimizer";
import useWorkflowTrace from "./useWorkflowTrace";
import useRecoveryPolicy from "./useRecoveryPolicy";
import useRecoveryPolicyAnalytics from "./useRecoveryPolicyAnalytics";

export default function useWorkflowOrchestrator() {
    const pipeline = useAiPipeline();
    const notifications = useNotifications();
    const activity = useActivityCenter();
    const engine = useExecutionEngine();
    const graph = useDependencyGraph();
    const optimizer = useWorkflowOptimizer();
    const trace = useWorkflowTrace();
    const recoveryPolicy = useRecoveryPolicy();
    const recoveryAnalytics = useRecoveryPolicyAnalytics();

    async function execute(workflow) {
        const workflowName =
            typeof workflow === "string"
                ? workflow
                : workflow?.name ||
                  workflow?.task ||
                  "unknown";

        activity.log(
            workflowName + " workflow started",
            "Running"
        );

        notifications.notify(
            workflowName + " started",
            "info"
        );

        trace.start(workflowName);

        try {
            const dependencyWorkflow =
                graph.getWorkflow(workflowName);

            if (!dependencyWorkflow.length) {
                throw new Error(
                    `No dependency graph found for workflow: ${workflowName}`
                );
            }

            const stages =
                optimizer.optimize(dependencyWorkflow);

            await engine.execute(
                stages,
                async stage => {
                    trace.stageStart(
                        workflowName,
                        stage
                    );

                    try {
                        if (typeof pipeline.runStage === "function") {
                            await pipeline.runStage(stage);
                        } else {
                            await pipeline.run(stage);
                        }

                        trace.stageComplete(
                            workflowName,
                            stage
                        );

                        recoveryAnalytics.record({
                            workflow: workflowName,
                            stage,
                            policy: "automatic-recovery",
                            decision: "Not Required",
                            status: "Completed",
                            attempts: 0,
                            outcome: "Completed"
                        });
                    } catch (error) {
                        const failure = {
                            workflow: workflowName,
                            event: "stage.failed",
                            status: "Failed",
                            stage,
                            message:
                                error?.message ||
                                `Stage ${stage} failed`,
                            metadata: {
                                error:
                                    error?.message ||
                                    String(error)
                            }
                        };

                        trace.record(failure);

                        const decision =
                            recoveryPolicy.evaluate(
                                failure,
                                0
                            );

                        recoveryAnalytics.record({
                            workflow: workflowName,
                            stage,
                            policy: "automatic-recovery",
                            decision:
                                decision.action === "retry"
                                    ? "Retry"
                                    : "Manual Intervention",
                            status: decision.allowed
                                ? "Retryable"
                                : "Blocked",
                            attempts: 0,
                            outcome: decision.allowed
                                ? "Retry Requested"
                                : "Failed",
                            reason: decision.reason
                        });

                        throw error;
                    }
                }
            );

            activity.log(
                workflowName + " workflow completed",
                "Completed"
            );

            notifications.notify(
                workflowName + " completed",
                "success"
            );

            trace.complete(workflowName);

            return {
                success: true,
                workflow: workflowName,
                stages,
                trace:
                    trace.getWorkflowTrace(
                        workflowName
                    )
            };
        } catch (error) {
            console.error(
                workflowName + " workflow failed:",
                error
            );

            activity.log(
                workflowName + " workflow failed",
                "Failed"
            );

            notifications.notify(
                workflowName + " failed",
                "error"
            );

            trace.fail(
                workflowName,
                error
            );

            recoveryAnalytics.record({
                workflow: workflowName,
                stage: engine.currentStage || "workflow",
                policy: "automatic-recovery",
                decision: "Manual Intervention",
                status: "Failed",
                attempts: 0,
                outcome: "Failed",
                reason:
                    error?.message ||
                    "Workflow execution failed"
            });

            return {
                success: false,
                workflow: workflowName,
                error,
                trace:
                    trace.getWorkflowTrace(
                        workflowName
                    )
            };
        }
    }

    return {
        execute,
        running: engine.running,
        currentStage: engine.currentStage,
        trace: trace.trace,
        recoveryAnalytics:
            recoveryAnalytics.analytics,
        getWorkflowTrace:
            trace.getWorkflowTrace,
        clearTrace:
            trace.clear
    };
}
