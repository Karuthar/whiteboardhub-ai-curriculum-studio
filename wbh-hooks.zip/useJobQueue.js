import { useState } from "react";

export default function useJobQueue() {

    const [jobs, setJobs] = useState([]);

    function addJob(title) {

        const job = {

            id: Date.now(),

            title,

            status: "Running",

            started: new Date()

        };

        setJobs(prev => [...prev, job]);

        return job.id;

    }

    function finishJob(id) {

        setJobs(prev =>
            prev.map(job =>
                job.id === id
                    ? { ...job, status: "Completed" }
                    : job
            )
        );

    }

    function failJob(id) {

        setJobs(prev =>
            prev.map(job =>
                job.id === id
                    ? { ...job, status: "Failed" }
                    : job
            )
        );

    }

    return {

        jobs,

        addJob,

        finishJob,

        failJob

    };

}