import { useState } from "react";

import useWorkflowOrchestrator from "./useWorkflowOrchestrator";
import useActivityCenter from "./useActivityCenter";
import useNotifications from "./useNotifications";
import useRecoveryPolicy from "./useRecoveryPolicy";

export default function useWorkflowRecovery() {

    const orchestrator = useWorkflowOrchestrator();
    const activity = useActivityCenter();
    const notifications = useNotifications();
    const { evaluate } = useRecoveryPolicy();

    const [recovering, setRecovering] = useState(false);

    const [recoveryState, setRecoveryState] =
        useState({});

    const [retryCounts, setRetryCounts] =
        useState({});

    async function recover(entry) {

        if (!entry?.workflow) {
            return false;
        }

        const id = entry.id;
        const workflow = entry.workflow;

        const retryCount =
            retryCounts[id] || 0;

        const decision =
            evaluate(entry, retryCount);

        if (!decision.allowed) {

            setRecoveryState(prev => ({
                ...prev,
                [id]: "Manual"
            }));

            activity.log(
                `Recovery blocked for ${workflow}: ${decision.reason}`,
                "Blocked"
            );

            notifications.notify(
                `${workflow}: ${decision.reason}`,
                "warning"
            );

            return false;

        }

        setRecovering(true);

        setRecoveryState(prev => ({
            ...prev,
            [id]: "Running"
        }));

        setRetryCounts(prev => ({
            ...prev,
            [id]: retryCount + 1
        }));

        activity.log(
            `Recovery attempt ${retryCount + 1} started for ${workflow}`,
            "Running"
        );

        notifications.notify(
            `Recovering ${workflow}...`,
            "info"
        );

        try {

            await orchestrator.execute(workflow);

            setRecoveryState(prev => ({
                ...prev,
                [id]: "Completed"
            }));

            activity.log(
                `Recovery completed for ${workflow}`,
                "Completed"
            );

            notifications.notify(
                `${workflow} recovery completed.`,
                "success"
            );

            return true;

        }

        catch (error) {

            console.error(
                "Workflow recovery failed:",
                error
            );

            setRecoveryState(prev => ({
                ...prev,
                [id]: "Failed"
            }));

            activity.log(
                `Recovery failed for ${workflow}`,
                "Failed"
            );

            notifications.notify(
                `${workflow} recovery failed.`,
                "error"
            );

            return false;

        }

        finally {

            setRecovering(false);

        }

    }

    function getRecoveryStatus(entry) {

        return recoveryState[entry?.id] || "Ready";

    }

    function getRetryCount(entry) {

        return retryCounts[entry?.id] || 0;

    }

    function getRecoveryDecision(entry) {

        return evaluate(
            entry,
            getRetryCount(entry)
        );

    }

    return {

        recover,
        recovering,
        recoveryState,
        retryCounts,
        getRecoveryStatus,
        getRetryCount,
        getRecoveryDecision

    };

}