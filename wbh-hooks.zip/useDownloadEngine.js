export default function useDownloadEngine(studio){

    async function completeCustomization(){}

    async function downloadSelectedDocument(){}

    return{

        completeCustomization,

        downloadSelectedDocument

    };

}