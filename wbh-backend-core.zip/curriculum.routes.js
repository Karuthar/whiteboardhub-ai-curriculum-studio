import express from "express";
import multer from "multer";

import {
  uploadCurriculum,
  parseCurriculum,
  generateScheme,
  getCurricula,
  getSchemes,
  getSchemeById,
  deleteCurriculum,
  deleteScheme
} from "../controllers/curriculum.controller.js";

const router = express.Router();

const upload = multer({
  dest: "uploads/"
});

// Scheme routes must come before dynamic curriculum ID routes
router.get("/schemes", getSchemes);
router.get("/schemes/:schemeId", getSchemeById);
router.delete("/schemes/:schemeId", deleteScheme);

// Curriculum routes
router.post("/upload", upload.single("curriculumFile"), uploadCurriculum);
router.get("/", getCurricula);
router.post("/:curriculumId/parse", parseCurriculum);
router.post("/:curriculumId/generate-scheme", generateScheme);
router.delete("/:curriculumId", deleteCurriculum);

export default router;