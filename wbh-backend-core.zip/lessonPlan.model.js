import mongoose from "mongoose";

const lessonPlanSchema = new mongoose.Schema(
  {
    schemeId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "SchemeOfWork",
      required: true
    },
    curriculumId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Curriculum"
    },
    termNumber: Number,
    weekNumber: Number,
    lessonNumber: Number,
    subject: String,
    grade: String,
    lessonTitle: String,
    strand: String,
    subStrand: String,
    durationMinutes: {
      type: Number,
      default: 40
    },
    learningOutcomes: [String],
    keyInquiryQuestion: String,
    learningResources: [String],
    introduction: String,
    lessonDevelopment: [
      {
        phase: String,
        teacherActivity: String,
        learnerActivity: String,
        timeMinutes: Number
      }
    ],
    assessment: [String],
    reflection: String,
    homework: String,
    generatedBy: {
      type: String,
      enum: ["fallback", "ai"],
      default: "fallback"
    }
  },
  { timestamps: true }
);

export default mongoose.model("LessonPlan", lessonPlanSchema);
