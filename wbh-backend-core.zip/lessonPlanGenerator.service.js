import OpenAI from "openai";

export async function generateLessonPlanFromSchemeLesson({
  scheme,
  termNumber,
  weekNumber,
  lessonNumber,
  durationMinutes
}) {
  const term = scheme.terms.find((t) => t.termNumber === Number(termNumber));
  const week = term?.weeks.find((w) => w.weekNumber === Number(weekNumber));

  const lesson = findLesson(week, lessonNumber);

  if (!term || !week || !lesson) {
    throw new Error("Selected term, week, or lesson was not found in the scheme.");
  }

  const finalDuration = Number(durationMinutes) || lesson.durationMinutes || 40;

  if (!process.env.OPENAI_API_KEY) {
    return fallbackLessonPlan(
      scheme,
      termNumber,
      weekNumber,
      lessonNumber,
      lesson,
      finalDuration
    );
  }

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    const response = await client.responses.create({
      model: process.env.AI_MODEL || "gpt-5.4",
      input: `
Generate a CBC/KICD-style Biology lesson plan as JSON only.

IMPORTANT PEDAGOGY RULE:
Use inquiry-based learning internally through the 5E flow:
Engage, Explore, Explain, Elaborate, Evaluate.
Do NOT print the words Engage, Explore, Explain, Elaborate, Evaluate unless naturally needed.
Blend them into Introduction, Development, Conclusion, Extended Activities, and Assessment.

Use this JSON shape:
{
  "lessonTitle": "string",
  "strand": "string",
  "subStrand": "string",
  "durationMinutes": ${finalDuration},
  "learningOutcomes": ["string"],
  "keyInquiryQuestion": "string",
  "learningResources": ["string"],
  "introduction": "string",
  "lessonDevelopment": [
    {
      "phase": "Introduction/Development/Conclusion",
      "teacherActivity": "string",
      "learnerActivity": "string",
      "timeMinutes": 0
    }
  ],
  "assessment": ["string"],
  "reflection": "string",
  "homework": "string"
}

Use the EXACT selected scheme lesson details below as the main source of truth.
Do not invent a different strand, sub-strand, SLO, resource list, or assessment focus.

Selected scheme lesson:
${JSON.stringify(lesson, null, 2)}

Lesson duration requested:
${finalDuration} minutes
`
    });

    const parsed = JSON.parse(response.output_text);

    return {
      ...parsed,
      subject: scheme.subject,
      grade: scheme.grade,
      termNumber: Number(termNumber),
      weekNumber: Number(weekNumber),
      lessonNumber: Number(lessonNumber),
      durationMinutes: finalDuration,
      generatedBy: "ai"
    };
  } catch (error) {
    console.log("AI lesson plan generation failed. Using fallback.");
    console.log(error.message);

    return fallbackLessonPlan(
      scheme,
      termNumber,
      weekNumber,
      lessonNumber,
      lesson,
      finalDuration
    );
  }
}

function findLesson(week, lessonNumber) {
  if (!week) return null;

  const selected = Number(lessonNumber);

  return (
    week.lessons.find((l) => Number(l.lessonNumber) === selected) ||
    week.lessons.find((l) => String(l.lessonNumber) === String(lessonNumber)) ||
    null
  );
}

function fallbackLessonPlan(
  scheme,
  termNumber,
  weekNumber,
  lessonNumber,
  lesson,
  durationMinutes = 40
) {
  const developmentTime = durationMinutes >= 80 ? 65 : 25;

  const selectedSloText = (lesson.learningOutcomes || []).join(" ");
  const selectedExperienceText = (lesson.learningExperiences || []).join(" ");

  return {
    subject: scheme.subject,
    grade: scheme.grade,
    termNumber: Number(termNumber),
    weekNumber: Number(weekNumber),
    lessonNumber: Number(lessonNumber),

    lessonTitle:
      lesson.lessonTitle ||
      lesson.subStrand ||
      `${lesson.strand || "Biology"} Lesson`,

    strand: lesson.strand || "",
    subStrand: lesson.subStrand || "",
    durationMinutes,

    learningOutcomes: lesson.learningOutcomes || [],

    keyInquiryQuestion:
      lesson.keyInquiryQuestion ||
      (Array.isArray(lesson.keyInquiryQuestions)
        ? lesson.keyInquiryQuestions[0]
        : "") ||
      buildFallbackKIQ(lesson),

    learningResources:
      lesson.resources ||
      lesson.learningResources ||
      [
        "Curriculum design",
        "Charts",
        "Digital devices",
        "Locally available materials"
      ],

    introduction:
      `Learners recall prior knowledge related to ${lesson.subStrand || "the lesson"} and respond to guiding questions that prepare them to investigate the lesson concept.`,

    lessonDevelopment: [
      {
        phase: "Introduction",
        teacherActivity:
          "Guide learners to recall previous learning, pose probing questions, and connect prior knowledge to the new lesson focus.",
        learnerActivity:
          `Respond to oral questions, share prior knowledge, and identify what they already know about ${lesson.subStrand || "the topic"}.`,
        timeMinutes: 5
      },
      {
        phase: "Development",
        teacherActivity:
          "Facilitate inquiry-based learning through guided observation, discussion, demonstration, group activity, explanation, and learner presentations.",
        learnerActivity:
          selectedExperienceText ||
          `Work individually, in pairs, or in groups to investigate ${lesson.subStrand || "the concept"}, discuss findings, record observations, and present conclusions.`,
        timeMinutes: developmentTime
      },
      {
        phase: "Conclusion",
        teacherActivity:
          "Guide learners to summarise key points, clarify misconceptions, and connect the lesson to real-life biological applications.",
        learnerActivity:
          selectedSloText ||
          "Summarise the main learning points, ask questions, and complete a short consolidation task.",
        timeMinutes: 5
      }
    ],

    assessment:
      lesson.assessment ||
      lesson.assessmentMethods ||
      [
        "Oral questioning",
        "Observation of learner participation",
        "Short written task",
        "Review of group presentation or learner responses"
      ],

    reflection:
      "Teacher notes learner participation, concept mastery, challenges encountered, and areas requiring reinforcement or remediation.",

    homework:
      `Learners complete an extended activity related to ${lesson.subStrand || "the lesson"} and prepare for the next lesson.`,

    generatedBy: "fallback"
  };
}

function buildFallbackKIQ(lesson) {
  if (lesson.subStrand) {
    return `How can we investigate and apply concepts related to ${lesson.subStrand}?`;
  }

  if (lesson.strand) {
    return `How can we apply today's concept in ${lesson.strand} to real-life situations?`;
  }

  return "How can we apply today's biological concept in real life?";
}