import mongoose from "mongoose";

const schemeOfWorkSchema = new mongoose.Schema(
  {
    curriculumId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Curriculum",
      required: true
    },

    title: { type: String, required: true },
    grade: String,
    subject: String,
    academicYear: String,

    lessonsPerWeek: { type: Number, default: 5 },
    lessonDurationMinutes: { type: Number, default: 40 },

    terms: [
      {
        termNumber: Number,
        numberOfWeeks: Number,
        weeks: [
          {
            weekNumber: Number,
            lessons: [
              {
                lessonNumber: Number,
                strand: String,
                subStrand: String,
                lessonTitle: String,
                learningOutcomes: [String],
                learningExperiences: [String],
                resources: [String],
                assessment: [String],
                remarks: String
              }
            ]
          }
        ]
      }
    ]
  },
  { timestamps: true }
);

export default mongoose.model("SchemeOfWork", schemeOfWorkSchema);
