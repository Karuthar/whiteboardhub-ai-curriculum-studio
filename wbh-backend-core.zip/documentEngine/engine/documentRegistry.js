import { getBuilder } from "./builderRegistry.js";
import { getTemplate } from "./templateRegistry.js";

export function getDocumentPipeline(document) {

    const type = document.sourceDocumentType;

    const builder = getBuilder(type);

    const template = getTemplate(type);

    if (!builder) {
        throw new Error(
            `No builder registered for document type: ${type}`
        );
    }

    if (!template) {
        throw new Error(
            `No template registered for document type: ${type}`
        );
    }

    return {

        type,

        builder,

        template,

        source: document

    };

}