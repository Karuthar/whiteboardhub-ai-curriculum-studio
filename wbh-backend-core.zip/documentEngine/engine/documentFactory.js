import { getPlugin }
from "./pluginRegistry.js";

import { getBuilder }
from "./builderRegistry.js";

import { getTemplate }
from "./templateRegistry.js";

export function createDocument(document) {

    const plugin =
        getPlugin(
            document.sourceDocumentType
        );

    if (!plugin)
        throw new Error(
            "Plugin not found."
        );

    return {

        source:
            document.documentData || {},

        builder:
            getBuilder(plugin.id),

        template:
            getTemplate(plugin.id),

        plugin

    };

}