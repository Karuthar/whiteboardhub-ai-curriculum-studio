import { buildSchemeRows }
from "../builders/scheme.builder.js";

import { buildLessonPlanRows }
from "../builders/lessonPlan.builder.js";

import { buildLessonNotesRows }
from "../builders/lessonNotes.builder.js";

const builders = {

    scheme: buildSchemeRows,

    lessonPlan: buildLessonPlanRows,

    lessonNotes: buildLessonNotesRows

};

export function getBuilder(type){

    return builders[type] || null;

}