export function renderDocument(
    template,
    source,
    rows
) {

    return template(
        source,
        rows
    );

}