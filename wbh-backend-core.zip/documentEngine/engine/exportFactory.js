import {
    exportCustomDocumentToDocx
}
from "../../customDocumentExport.service.js";

export async function exportGeneratedDocument(document) {

    return exportCustomDocumentToDocx(document);

}