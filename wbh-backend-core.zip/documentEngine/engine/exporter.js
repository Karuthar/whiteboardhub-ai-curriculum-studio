import {
    exportGeneratedDocument
}
from "./exportFactory.js";

export {
    exportGeneratedDocument
};