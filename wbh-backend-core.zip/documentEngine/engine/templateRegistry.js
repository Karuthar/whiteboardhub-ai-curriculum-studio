import { buildSchemeTemplate }
from "../templates/scheme.template.js";

import { buildLessonPlanTemplate }
from "../templates/lessonPlan.template.js";

import { buildLessonNotesTemplate }
from "../templates/lessonNotes.template.js";

const templates = {

    scheme: buildSchemeTemplate,

    lessonPlan: buildLessonPlanTemplate,

    lessonNotes: buildLessonNotesTemplate

};

export function getTemplate(type){

    return templates[type] || null;

}