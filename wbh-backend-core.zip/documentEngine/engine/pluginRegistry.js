import scheme from "../../documents/scheme/metadata.js";

const registry = {

    scheme

};

export function getPlugin(type) {

    return registry[type] || null;

}