import { getDocumentPipeline }
from "./documentRegistry.js";

import {
    renderDocument
}
from "./renderer.js";

import {
    exportGeneratedDocument
}
from "./exporter.js";

export async function generateDocument(document) {

    const pipeline =
        getDocumentPipeline(document);

    const rows =
        pipeline.builder(
            pipeline.source
        );

    document.contentHtml =
        renderDocument(
            pipeline.template,
            pipeline.source,
            rows
        );

    return exportGeneratedDocument(document);

}