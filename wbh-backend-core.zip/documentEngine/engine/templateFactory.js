export function createTemplate(
    template,
    source,
    rows
) {

    return template(
        source,
        rows
    );

}