export function buildSchemeRows(scheme) {

const rows = [];

if (!scheme?.terms) {
return rows;
}

scheme.terms.forEach((term) => {

```
term.weeks.forEach((week) => {

  week.lessons.forEach((lesson) => {

    rows.push({
      term: term.termNumber,
      week: week.weekNumber,

      lesson:
        lesson.lessonNumber || "",

      strand:
        lesson.strand || "",

      subStrand:
        lesson.subStrand || "",

      outcomes:
        lesson.learningOutcomes || "",

      experiences:
        lesson.learningExperiences || "",

      resources:
        Array.isArray(lesson.resources)
          ? lesson.resources.join(", ")
          : "",

      assessment:
        lesson.assessment || "",

      remarks:
        lesson.remarks || ""
    });

  });

});
```

});

return rows;
}