export function buildLessonNotesRows(notes) {

    return [

        {

            topic: notes.topic || "",

            subTopic: notes.subTopic || "",

            objectives: notes.objectives || [],

            introduction: notes.introduction || "",

            content: notes.content || "",

            activities: notes.activities || [],

            summary: notes.summary || "",

            assignment: notes.assignment || ""

        }

    ];

}