export function buildLessonPlanRows(lessonPlan) {

    return [
        {
            lessonTitle: lessonPlan.lessonTitle || "",
            subject: lessonPlan.subject || "",
            grade: lessonPlan.grade || "",
            strand: lessonPlan.strand || "",
            subStrand: lessonPlan.subStrand || "",
            outcomes: lessonPlan.learningOutcomes || [],
            activities: lessonPlan.learningExperiences || [],
            resources: lessonPlan.resources || [],
            assessment: lessonPlan.assessment || [],
            reflection: lessonPlan.reflection || ""
        }
    ];

}