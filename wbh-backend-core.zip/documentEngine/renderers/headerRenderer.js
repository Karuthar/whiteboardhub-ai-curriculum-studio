export function renderHeader(document) {

  const meta = document.customizationMeta || {};

  return `

<div class="wb-header">

  <div class="wb-school">

    ${meta.schoolName || ""}

  </div>

  <div class="wb-title">

    ${document.title || ""}

  </div>

  <table class="wb-meta">

    <tr>

      <td><strong>Teacher</strong></td>
      <td>${meta.teacherName || ""}</td>

      <td><strong>Class</strong></td>
      <td>${meta.className || ""}</td>

    </tr>

    <tr>

      <td><strong>Academic Year</strong></td>
      <td>${meta.academicYear || ""}</td>

      <td><strong>Term</strong></td>
      <td>${meta.term || ""}</td>

    </tr>

    <tr>

      <td><strong>Week</strong></td>
      <td>${meta.week || ""}</td>

      <td><strong>Lesson</strong></td>
      <td>${meta.lesson || ""}</td>

    </tr>

  </table>

</div>

`;

}