import {
renderHeader
} from "./headerRenderer.js";

import {
renderFooter
} from "./footerRenderer.js";

import {
renderBranding
} from "./brandingRenderer.js";

import {
renderStyles
} from "./styleRenderer.js";

export function renderDocument(document, bodyHtml) {

return `

<html>

<head>

${renderStyles()}

</head>

<body>

${renderBranding(document)}

${renderHeader(document)}

${bodyHtml}

${renderFooter()}

</body>

</html>

`;

}