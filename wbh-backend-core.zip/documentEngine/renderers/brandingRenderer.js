export function renderBranding(document) {

const meta =
document.customizationMeta || {};

return `

<div class="wb-branding">

${
meta.logoUrl
? `<img class="wb-logo" src="${meta.logoUrl}">`
: ""
}

${
meta.stampUrl
? `<img class="wb-stamp" src="${meta.stampUrl}">`
: ""
}

</div>

`;

}