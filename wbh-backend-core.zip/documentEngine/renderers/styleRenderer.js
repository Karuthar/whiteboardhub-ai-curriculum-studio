export function renderStyles() {

return `

<style>

body{

font-family:Arial,sans-serif;

font-size:12px;

color:#1f2937;

line-height:1.6;

}

.wb-header{

margin-bottom:20px;

border-bottom:3px solid #123d6b;

padding-bottom:15px;

}

.wb-school{

font-size:28px;

font-weight:bold;

text-align:center;

color:#123d6b;

}

.wb-title{

font-size:18px;

font-weight:bold;

text-align:center;

margin-top:10px;

margin-bottom:20px;

}

.wb-meta{

width:100%;

border-collapse:collapse;

}

.wb-meta td{

padding:6px;

}

.wb-footer{

margin-top:30px;

text-align:center;

font-size:11px;

color:#666;

}

.wb-logo{

height:70px;

}

.wb-stamp{

height:80px;

float:right;

}

</style>

`;

}