import {
  generateDocument
} from "../engine/documentEngine.js";

export async function exportSchemeDocument(document) {

  return generateDocument(document);

}