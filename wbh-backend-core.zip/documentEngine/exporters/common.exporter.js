import fs from "fs";
import path from "path";
import htmlToDocx from "html-to-docx";

function sanitizeHtml(html = "") {
  return html
    .replace(/contenteditable="true"/gi, "")
    .replace(/contenteditable="false"/gi, "")
    .replace(/class="[^"]*"/gi, "")
    .replace(/data-[^=]+="[^"]*"/gi, "")
    .replace(/spellcheck="[^"]*"/gi, "")
    .replace(/aria-[^=]+="[^"]*"/gi, "")
    .replace(/ProseMirror/gi, "")
    .replace(/<p>\s*<\/p>/gi, "")
    .replace(/style=""/gi, "")
    .replace(
      /<div class="document-export-details">[\s\S]*?<\/div>/gi,
      ""
    );
}

function embedLocalImages(html = "") {
  return html.replace(
    /src="http:\/\/localhost:7000([^"]+)"/gi,
    (match, filePath) => {
      try {
        const fullPath = path.join(
          process.cwd(),
          filePath.replace(/^\/+/, "")
        );

        if (!fs.existsSync(fullPath)) {
          return match;
        }

        const imageBuffer = fs.readFileSync(fullPath);

        const base64 =
          imageBuffer.toString("base64");

        const ext =
          path.extname(fullPath)
            .replace(".", "")
            .toLowerCase();

        return `src="data:image/${ext};base64,${base64}"`;
      } catch (error) {
        console.log("Image embed failed:", error.message);
        return match;
      }
    }
  );
}

export async function exportCustomDocumentToDocx(document) {
  const exportsDir = path.join(
    process.cwd(),
    "exports"
  );

  if (!fs.existsSync(exportsDir)) {
    fs.mkdirSync(exportsDir, {
      recursive: true
    });
  }

  const safeTitle = (
    document.title || "custom-document"
  )
    .replace(/[^a-z0-9]/gi, "_")
    .toLowerCase();

  const filename = `${safeTitle}.docx`;

  const filePath = path.join(
    exportsDir,
    filename
  );

  const isLandscape =
    document.sourceDocumentType === "scheme" ||
    document.sourceDocumentType === "curriculum";

  const details =
    document.customizationMeta || {};

  const references =
    details.references || "";

  let cleanedHtml = sanitizeHtml(
    document.contentHtml || ""
  );

  // cleanedHtml = embedLocalImages(cleanedHtml);

  const html = `
<html>

<head>

<meta charset="utf-8"/>

<style>

@page{
  size:A4 ${
    isLandscape
      ? "landscape"
      : "portrait"
  };
  margin:15mm;
}

body{
  font-family:Arial,sans-serif;
  color:#1f2937;
  font-size:12px;
  line-height:1.6;
  padding:20px;
}

.doc-header{
  margin-bottom:25px;
  padding-bottom:15px;
  border-bottom:3px solid #123d6b;
}

.school-name{
  text-align:center;
  font-size:28px;
  font-weight:bold;
  color:#123d6b;
  text-transform:uppercase;
  margin-bottom:20px;
}

.document-title{
  text-align:center;
  font-size:18px;
  font-weight:bold;
  color:#123d6b;
  margin-bottom:15px;
}

.details-table{
  width:100%;
  border-collapse:collapse;
  margin-top:10px;
  margin-bottom:25px;
}

.details-table td{
  border:none;
  padding:6px 20px 6px 0;
  font-size:13px;
}

.details-label{
  font-weight:bold;
  color:#123d6b;
  width:160px;
}

h1,h2,h3,h4{
  color:#123d6b;
}

table{
  width:100%;
  border-collapse:collapse;
  margin-top:15px;
  margin-bottom:15px;
  table-layout:auto;
}

thead{
  background:#123d6b;
  color:white;
}

th{
  background:#123d6b;
  color:white;
  border:1px solid #cbd5e1;
  padding:10px;
  text-align:left;
  font-size:12px;
}

td{
  border:1px solid #cbd5e1;
  padding:10px;
  vertical-align:top;
  font-size:12px;
}

tr:nth-child(even){
  background:#f8fafc;
}

img{
  display:block;
  max-width:500px;
  width:auto;
  height:auto;
  margin-top:10px;
  margin-bottom:10px;
  border-radius:6px;
}

.references-section{
  margin-top:30px;
  border-top:2px solid #cbd5e1;
  padding-top:15px;
}

.references-title{
  font-size:18px;
  font-weight:bold;
  color:#123d6b;
  margin-bottom:10px;
}

.references-content{
  white-space:pre-wrap;
  line-height:1.8;
}

.footer{
  margin-top:30px;
  text-align:center;
  font-size:11px;
  color:#6b7280;
}

</style>

</head>

<body>

<div class="doc-header">

  <div class="school-name">
    ${details.schoolName || ""}
  </div>

  <div class="document-title">
    ${document.title || ""}
  </div>

  <table class="details-table">

    <tr>
      <td class="details-label">
        Teacher Name
      </td>
      <td>
        ${details.teacherName || ""}
      </td>

      <td class="details-label">
        Class / Grade
      </td>
      <td>
        ${details.className || ""}
      </td>
    </tr>

    <tr>
      <td class="details-label">
        Academic Year
      </td>
      <td>
        ${details.academicYear || ""}
      </td>

      <td class="details-label">
        Term
      </td>
      <td>
        ${details.term || ""}
      </td>
    </tr>

    <tr>
      <td class="details-label">
        Week
      </td>
      <td>
        ${details.week || ""}
      </td>

      <td class="details-label">
        Lesson
      </td>
      <td>
        ${details.lesson || ""}
      </td>
    </tr>

  </table>

</div>

${cleanedHtml}

${
  references
    ? `
<div class="references-section">

  <div class="references-title">
    References
  </div>

  <div class="references-content">
    ${references}
  </div>

</div>
`
    : ""
}

<div class="footer">
  Generated by WhiteboardHub AI Curriculum Studio
</div>

</body>

</html>
`;

  const buffer = await htmlToDocx(
    html,
    null,
    {
      orientation: isLandscape
        ? "landscape"
        : "portrait",

      pageNumber: true,

      footer: true,

      table: {
        row: {
          cantSplit: true
        }
      }
    }
  );

  fs.writeFileSync(
    filePath,
    buffer
  );

  return {
    filename,
    filePath
  };
}

export const exportDocument =
  exportCustomDocumentToDocx;