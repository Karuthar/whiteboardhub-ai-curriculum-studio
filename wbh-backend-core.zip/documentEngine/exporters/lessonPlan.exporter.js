import {
  generateDocument
} from "../engine/documentEngine.js";

export async function exportLessonPlanDocument(document) {

  return generateDocument(document);

}