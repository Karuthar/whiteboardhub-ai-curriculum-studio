import {
  generateDocument
} from "../engine/documentEngine.js";

export async function exportCurriculumDocument(document) {

  return generateDocument(document);

}