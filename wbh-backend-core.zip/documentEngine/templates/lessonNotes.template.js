export function buildLessonNotesTemplate(
    notes,
    rows
) {

    const row = rows[0];

    return `

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<style>

body{

font-family:Arial;

font-size:12px;

line-height:1.6;

color:#222;

padding:20px;

}

.title{

font-size:22px;

font-weight:bold;

text-align:center;

color:#123d6b;

margin-bottom:20px;

}

.section{

margin-top:20px;

}

h2{

color:#123d6b;

margin-bottom:8px;

}

ul{

margin-top:8px;

}

</style>

</head>

<body>

<div class="title">

${notes.lessonTitle || "Lesson Notes"}

</div>

<div class="section">

<h2>Topic</h2>

<p>

${row.topic}

</p>

</div>

<div class="section">

<h2>Sub Topic</h2>

<p>

${row.subTopic}

</p>

</div>

<div class="section">

<h2>Objectives</h2>

<ul>

${row.objectives.map(x=>`<li>${x}</li>`).join("")}

</ul>

</div>

<div class="section">

<h2>Introduction</h2>

<p>

${row.introduction}

</p>

</div>

<div class="section">

<h2>Lesson Content</h2>

${row.content}

</div>

<div class="section">

<h2>Learning Activities</h2>

<ul>

${row.activities.map(x=>`<li>${x}</li>`).join("")}

</ul>

</div>

<div class="section">

<h2>Summary</h2>

<p>

${row.summary}

</p>

</div>

<div class="section">

<h2>Assignment</h2>

<p>

${row.assignment}

</p>

</div>

</body>

</html>

`;

}