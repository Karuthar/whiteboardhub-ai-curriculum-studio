export function buildSchemeTemplate(
  scheme,
  rows
) {

  return `

<div class="scheme-header">

  <div class="scheme-title">
    ${scheme.title || ""}
  </div>

  <table class="scheme-meta">

    <tr>
      <td><strong>Subject</strong></td>
      <td>${scheme.subject || ""}</td>

      <td><strong>Grade</strong></td>
      <td>${scheme.grade || ""}</td>
    </tr>

  </table>

</div>

<table class="scheme-table">

  <thead>
    <tr>
      <th>Term</th>
      <th>Week</th>
      <th>Lesson</th>
      <th>Strand</th>
      <th>Sub-Strand</th>
      <th>Learning Outcomes</th>
      <th>Learning Experiences</th>
      <th>Resources</th>
      <th>Assessment</th>
      <th>Remarks</th>
    </tr>
  </thead>

  <tbody>

    ${rows.map(row => `
      <tr>
        <td>${row.term || ""}</td>
        <td>${row.week || ""}</td>
        <td>${row.lesson || ""}</td>
        <td>${row.strand || ""}</td>
        <td>${row.subStrand || ""}</td>
        <td>${row.outcomes || ""}</td>
        <td>${row.experiences || ""}</td>
        <td>${row.resources || ""}</td>
        <td>${row.assessment || ""}</td>
        <td>${row.remarks || ""}</td>
      </tr>
    `).join("")}

  </tbody>

</table>

`;
}