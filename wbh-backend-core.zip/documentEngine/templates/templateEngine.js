import {buildPage}
from "./components/page.template.js";

export function buildDocument(html){

return buildPage(html);

}