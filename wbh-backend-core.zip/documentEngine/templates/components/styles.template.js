export function documentStyles() {

return `

<style>

@page{
    margin:15mm;
}

body{

    font-family:Arial,sans-serif;
    font-size:12px;
    color:#1f2937;
    line-height:1.5;

}

h1{

    color:#123d6b;
    text-align:center;

}

h2{

    color:#123d6b;

}

table{

    width:100%;
    border-collapse:collapse;
    margin-top:15px;

}

th{

    background:#123d6b;
    color:white;
    border:1px solid #cccccc;
    padding:8px;

}

td{

    border:1px solid #cccccc;
    padding:8px;
    vertical-align:top;

}

tr:nth-child(even){

    background:#f8fafc;

}

.footer{

    margin-top:25px;
    text-align:center;
    font-size:11px;
    color:#777;

}

</style>

`;

}