export function buildHeader(meta={}){

return `

<div class="header">

<h1>${meta.schoolName || ""}</h1>

<h2>${meta.title || ""}</h2>

<table>

<tr>

<td><strong>Teacher</strong></td>
<td>${meta.teacherName || ""}</td>

<td><strong>Grade</strong></td>
<td>${meta.grade || ""}</td>

</tr>

<tr>

<td><strong>Subject</strong></td>
<td>${meta.subject || ""}</td>

<td><strong>Term</strong></td>
<td>${meta.term || ""}</td>

</tr>

</table>

</div>

`;

}