import {documentStyles}
from "./styles.template.js";

export function buildPage(body){

return `

<html>

<head>

<meta charset="utf-8">

${documentStyles()}

</head>

<body>

${body}

</body>

</html>

`;

}