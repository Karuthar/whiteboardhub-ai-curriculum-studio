export function buildLessonPlanTemplate(
    lesson,
    rows
) {

    const row = rows[0];

    return `
<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<style>

body{
font-family:Arial,sans-serif;
font-size:12px;
color:#222;
}

.lesson-title{
font-size:22px;
font-weight:bold;
text-align:center;
margin-bottom:20px;
color:#123d6b;
}

table{
width:100%;
border-collapse:collapse;
margin-top:15px;
}

th{
background:#123d6b;
color:white;
padding:8px;
border:1px solid #ccc;
}

td{
border:1px solid #ccc;
padding:8px;
vertical-align:top;
}

.section{
margin-top:18px;
}

</style>

</head>

<body>

<div class="lesson-title">

${lesson.lessonTitle || ""}

</div>

<table>

<tr>

<th>Subject</th>

<td>${lesson.subject || ""}</td>

<th>Grade</th>

<td>${lesson.grade || ""}</td>

</tr>

<tr>

<th>Strand</th>

<td>${lesson.strand || ""}</td>

<th>Sub-strand</th>

<td>${lesson.subStrand || ""}</td>

</tr>

</table>

<div class="section">

<h3>Learning Outcomes</h3>

<ul>

${(row.outcomes || []).map(item=>`<li>${item}</li>`).join("")}

</ul>

</div>

<div class="section">

<h3>Learning Activities</h3>

<ul>

${(row.activities || []).map(item=>`<li>${item}</li>`).join("")}

</ul>

</div>

<div class="section">

<h3>Resources</h3>

<ul>

${(row.resources || []).map(item=>`<li>${item}</li>`).join("")}

</ul>

</div>

<div class="section">

<h3>Assessment</h3>

<ul>

${(row.assessment || []).map(item=>`<li>${item}</li>`).join("")}

</ul>

</div>

<div class="section">

<h3>Reflection</h3>

<p>

${row.reflection || ""}

</p>

</div>

</body>

</html>

`;

}