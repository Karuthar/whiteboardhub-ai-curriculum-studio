export function buildBrandingHeader({
  schoolName = "",
  teacherName = "",
  className = "",
  academicYear = "",
  term = "",
  week = "",
  lesson = "",
  references = ""
}) {
  return `
    <div class="wb-document-header">

      <div class="wb-school-name">
        ${schoolName}
      </div>

      <table class="wb-details-table">

        <tr>
          <td class="wb-label">Teacher</td>
          <td>${teacherName}</td>

          <td class="wb-label">Class / Grade</td>
          <td>${className}</td>
        </tr>

        <tr>
          <td class="wb-label">Academic Year</td>
          <td>${academicYear}</td>

          <td class="wb-label">Term</td>
          <td>${term}</td>
        </tr>

        <tr>
          <td class="wb-label">Week</td>
          <td>${week}</td>

          <td class="wb-label">Lesson</td>
          <td>${lesson}</td>
        </tr>

      </table>

      ${
        references
          ? `
          <div class="wb-references">
            <strong>References:</strong>
            ${references}
          </div>
        `
          : ""
      }

    </div>
  `;
}

export function buildBrandingStyles() {
  return `
    body{
      font-family: Arial, Helvetica, sans-serif;
      color:#111827;
      padding:24px;
      line-height:1.5;
    }

    .wb-document-header{
      margin-bottom:24px;
      border-bottom:2px solid #1e3a8a;
      padding-bottom:16px;
    }

    .wb-school-name{
      text-align:center;
      font-size:28px;
      font-weight:bold;
      color:#1e3a8a;
      margin-bottom:20px;
      text-transform:uppercase;
    }

    .wb-details-table{
      width:100%;
      border-collapse:collapse;
      margin-bottom:15px;
    }

    .wb-details-table td{
      padding:8px;
      border:none;
    }

    .wb-label{
      font-weight:bold;
      color:#1e3a8a;
      width:180px;
    }

    .wb-references{
      margin-top:12px;
      padding-top:10px;
      border-top:1px solid #d1d5db;
      white-space:pre-wrap;
    }

    table{
      width:100%;
      border-collapse:collapse;
      table-layout:auto;
    }

    th{
      background:#1e3a8a;
      color:white;
      border:1px solid #94a3b8;
      padding:10px;
      text-align:left;
      font-size:12px;
    }

    td{
      border:1px solid #cbd5e1;
      padding:10px;
      vertical-align:top;
      font-size:12px;
    }

    tr:nth-child(even){
      background:#f8fafc;
    }

    img{
      max-width:100%;
      height:auto;
      display:block;
      margin-top:10px;
      margin-bottom:10px;
      border-radius:8px;
    }

    h1,h2,h3,h4{
      color:#1e3a8a;
    }
  `;
}