import mongoose from "mongoose";

const learningResourceSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true
    },

    originalFileName: {
      type: String,
      required: true
    },

    storedFileName: {
      type: String,
      required: true
    },

    filePath: {
      type: String,
      required: true
    },

    mimeType: {
      type: String,
      required: true
    },

    resourceType: {
      type: String,
      enum: ["image", "video", "pdf", "docx", "document", "other"],
      default: "other",
      index: true
    },

    grade: {
      type: String,
      default: ""
    },

    subject: {
      type: String,
      default: ""
    },

    topic: {
      type: String,
      default: ""
    },

    subTopic: {
      type: String,
      default: ""
    },

    extractedText: {
      type: String,
      default: ""
    },

    previewUrl: {
      type: String,
      default: ""
    },

    index: {
      type: {
        type: String,
        default: "learningResource"
      },
      gradeLevel: {
        type: String,
        default: ""
      },
      learningArea: {
        type: String,
        default: ""
      },
      resourceCategory: {
        type: String,
        default: ""
      }
    },

    monetization: {
      platformOwned: {
        type: Boolean,
        default: true
      },
      monetizable: {
        type: Boolean,
        default: true
      },
      license: {
        type: String,
        default: "platform-resource"
      }
    },

    status: {
      type: String,
      enum: ["active", "archived"],
      default: "active",
      index: true
    }
  },
  {
    timestamps: true
  }
);

learningResourceSchema.index({
  resourceType: 1,
  grade: 1,
  subject: 1,
  topic: 1
});

const LearningResource = mongoose.model(
  "LearningResource",
  learningResourceSchema
);

export default LearningResource;