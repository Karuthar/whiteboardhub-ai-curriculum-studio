import fs from "fs";
import path from "path";
import PDFDocument from "pdfkit";

import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  Table,
  TableRow,
  TableCell,
  WidthType,
  BorderStyle,
  AlignmentType,
  PageOrientation
} from "docx";

/* =========================
   HELPERS
========================= */

function ensureExportDir() {
  const exportDir = path.join(process.cwd(), "exports");

  if (!fs.existsSync(exportDir)) {
    fs.mkdirSync(exportDir, { recursive: true });
  }

  return exportDir;
}

function p(text = "") {
  return new Paragraph(String(text || ""));
}

function bullet(text = "") {
  return new Paragraph(`• ${text}`);
}

const tableBorders = {
  top: { style: BorderStyle.SINGLE, size: 1 },
  bottom: { style: BorderStyle.SINGLE, size: 1 },
  left: { style: BorderStyle.SINGLE, size: 1 },
  right: { style: BorderStyle.SINGLE, size: 1 },
  insideHorizontal: { style: BorderStyle.SINGLE, size: 1 },
  insideVertical: { style: BorderStyle.SINGLE, size: 1 }
};

function cell(text, width, bold = false) {
  return new TableCell({
    width: {
      size: width,
      type: WidthType.PERCENTAGE
    },

    children: [
      new Paragraph({
        children: [
          new TextRun({
            text: String(text || ""),
            bold,
            size: 18
          })
        ]
      })
    ]
  });
}

function headerCell(text, width) {
  return new TableCell({
    width: {
      size: width,
      type: WidthType.PERCENTAGE
    },

    shading: {
      fill: "D9EAF7"
    },

    children: [
      new Paragraph({
        alignment: AlignmentType.CENTER,

        children: [
          new TextRun({
            text,
            bold: true,
            size: 18
          })
        ]
      })
    ]
  });
}

function formatLessonNumber(lesson, scheme) {
  const subject = String(scheme.subject || "").toLowerCase();

  const isScienceOrTechnical =
    subject.includes("biology") ||
    subject.includes("chemistry") ||
    subject.includes("physics") ||
    subject.includes("home science") ||
    subject.includes("computer science") ||
    subject.includes("woodwork") ||
    subject.includes("wood work") ||
    subject.includes("metalwork") ||
    subject.includes("metal work") ||
    subject.includes("building") ||
    subject.includes("construction") ||
    subject.includes("aviation") ||
    subject.includes("technical");

  if (!isScienceOrTechnical) return lesson.lessonNumber;

  if (lesson.lessonNumber === 2 || lesson.lessonNumber === "2") return "2 & 3";

  if (lesson.lessonNumber === 3 || lesson.lessonNumber === "3") return "";

  return lesson.lessonNumber;
}

function savePdf(filename, writer) {
  const exportDir = ensureExportDir();

  const filePath = path.join(exportDir, filename);

  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      margin: 50
    });

    const stream = fs.createWriteStream(filePath);

    doc.pipe(stream);

    writer(doc);

    doc.end();

    stream.on("finish", () => {
      resolve({
        filename,
        filePath
      });
    });

    stream.on("error", reject);
  });
}

function writePdfSection(doc, title, content = "") {
  doc.fontSize(14).text(title, {
    underline: true
  });

  doc.moveDown(0.5);

  doc.fontSize(11).text(content || "Not provided.");

  doc.moveDown();
}

function writePdfList(doc, title, items = []) {
  doc.fontSize(14).text(title, {
    underline: true
  });

  doc.moveDown(0.5);

  if (!items?.length) {
    doc.fontSize(11).text("Not provided.");
  } else {
    items.forEach((item) => {
      doc.fontSize(11).text(`• ${item}`);
    });
  }

  doc.moveDown();
}

/* =========================
   SCHEME EXPORTS
========================= */

export async function exportSchemeToWord(scheme) {
  const rows = [];

  rows.push(
    new TableRow({
      children: [
        headerCell("Wk", 4),
        headerCell("Lsn", 4),
        headerCell("Strand", 11),
        headerCell("Sub-strand", 12),
        headerCell("Specific Learning Outcomes", 20),
        headerCell("Learning Experiences", 20),
        headerCell("Key Inquiry Question", 10),
        headerCell("Learning Resources", 10),
        headerCell("Assessment Methods", 7),
        headerCell("Reflection", 5)
      ]
    })
  );

  (scheme.terms || []).forEach((term) => {
    rows.push(
      new TableRow({
        children: [
          new TableCell({
            columnSpan: 10,

            shading: {
              fill: "EEEEEE"
            },

            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,

                children: [
                  new TextRun({
                    text: `TERM ${term.termNumber}`,
                    bold: true,
                    size: 20
                  })
                ]
              })
            ]
          })
        ]
      })
    );

    (term.weeks || []).forEach((week) => {
      (week.lessons || []).forEach((lesson) => {
        rows.push(
          new TableRow({
            children: [
              cell(week.weekNumber, 4),
              cell(formatLessonNumber(lesson, scheme), 4),
              cell(lesson.strand, 11),
              cell(lesson.subStrand, 12),

              cell(
                (lesson.learningOutcomes || []).join("\n"),
                20
              ),

              cell(
                (lesson.learningExperiences || []).join("\n"),
                20
              ),

              cell(
                Array.isArray(lesson.keyInquiryQuestions)
                  ? lesson.keyInquiryQuestions.join("\n")
                  : lesson.keyInquiryQuestion || "",
                10
              ),

              cell(
                (lesson.resources || []).join("\n"),
                10
              ),

              cell(
                (lesson.assessment || []).join("\n"),
                7
              ),

              cell("", 5)
            ]
          })
        );
      });
    });
  });

  const children = [
    new Paragraph({
      alignment: AlignmentType.CENTER,

      children: [
        new TextRun({
          text: "GRADE 10 BIOLOGY SCHEME OF WORK",
          bold: true,
          size: 28
        })
      ]
    }),

    new Paragraph(""),

    new Table({
      width: {
        size: 100,
        type: WidthType.PERCENTAGE
      },

      borders: tableBorders,

      rows: [
        new TableRow({
          children: [
            cell("School: ........................................", 25),
            cell("Teacher: ........................................", 25),
            cell("TSC No: ........................................", 25),
            cell(
              `Year: ${scheme.academicYear || "................"}`,
              25
            )
          ]
        }),

        new TableRow({
          children: [
            cell(
              `Subject: ${scheme.subject || "Biology"}`,
              25
            ),

            cell(
              `Grade: ${scheme.grade || "10"}`,
              25
            ),

            cell("Term: ................", 25),
            cell("Class: ................", 25)
          ]
        })
      ]
    }),

    new Paragraph(""),

    new Table({
      width: {
        size: 100,
        type: WidthType.PERCENTAGE
      },

      borders: tableBorders,

      rows
    })
  ];

  const filename = `professional-scheme-${scheme._id}.docx`;

  const filePath = path.join(
    ensureExportDir(),
    filename
  );

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            size: {
              orientation: PageOrientation.LANDSCAPE
            },

            margin: {
              top: 720,
              right: 720,
              bottom: 720,
              left: 720
            }
          }
        },

        children
      }
    ]
  });

  const buffer = await Packer.toBuffer(doc);

  fs.writeFileSync(filePath, buffer);

  return {
    filename,
    filePath
  };
}

export async function exportSchemeToPdf(scheme) {
  return savePdf(
    `scheme-${scheme._id}.pdf`,
    (doc) => {
      doc
        .fontSize(18)
        .text(
          "WhiteboardHub AI Curriculum Studio",
          {
            align: "center"
          }
        );

      doc.moveDown();

      doc
        .fontSize(16)
        .text(
          scheme.title || "Scheme of Work",
          {
            underline: true
          }
        );

      doc.moveDown();

      doc
        .fontSize(11)
        .text(
          `Subject: ${scheme.subject || ""}`
        );

      doc.text(
        `Grade: ${scheme.grade || ""}`
      );

      doc.text(
        `Academic Year: ${
          scheme.academicYear || ""
        }`
      );

      doc.moveDown();

      (scheme.terms || []).forEach(
        (term) => {
          doc
            .fontSize(14)
            .text(
              `Term ${term.termNumber}`,
              {
                underline: true
              }
            );

          doc.moveDown(0.5);

          (term.weeks || []).forEach(
            (week) => {
              doc
                .fontSize(12)
                .text(
                  `Week ${week.weekNumber}`
                );

              (week.lessons || []).forEach(
                (lesson) => {
                  doc
                    .fontSize(10)
                    .text(
                      `Lesson ${
                        lesson.lessonNumber || ""
                      }: ${
                        lesson.lessonTitle || ""
                      }`
                    );

                  doc.text(
                    `Strand: ${
                      lesson.strand || ""
                    }`
                  );

                  doc.text(
                    `Sub-strand: ${
                      lesson.subStrand || ""
                    }`
                  );

                  doc.moveDown(0.4);
                }
              );
            }
          );
        }
      );
    }
  );
}

/* =========================
   LESSON PLAN EXPORTS
========================= */

export async function exportLessonPlanToWord(
  lessonPlan
) {
  function infoCell(label, value) {
    return new TableCell({
      children: [
        new Paragraph({
          children: [
            new TextRun({
              text: `${label}: `,
              bold: true,
              size: 20
            }),

            new TextRun({
              text: String(
                value ||
                  "................................"
              ),
              size: 20
            })
          ]
        })
      ]
    });
  }

  function sectionHeader(
    text,
    columnSpan = 6
  ) {
    return new TableRow({
      children: [
        new TableCell({
          columnSpan,

          shading: {
            fill: "D9EAF7"
          },

          children: [
            new Paragraph({
              alignment:
                AlignmentType.CENTER,

              children: [
                new TextRun({
                  text,
                  bold: true,
                  size: 22
                })
              ]
            })
          ]
        })
      ]
    });
  }

  function textCell(
    text,
    width,
    bold = false
  ) {
    return new TableCell({
      width: {
        size: width,
        type: WidthType.PERCENTAGE
      },

      children: [
        new Paragraph({
          children: [
            new TextRun({
              text: String(text || ""),
              bold,
              size: 19
            })
          ]
        })
      ]
    });
  }

  const learningOutcomes =
    (
      lessonPlan.learningOutcomes || []
    ).join("\n");

  const resources =
    (
      lessonPlan.learningResources || []
    ).join("\n");

  const assessment =
    (
      lessonPlan.assessment || []
    ).join("\n");

  const intro =
    lessonPlan.introduction ||
    "Learners are guided to recall prior knowledge and respond to probing questions related to the lesson.";

  const development =
    (
      lessonPlan.lessonDevelopment || []
    )
      .map(
        (phase) =>
          `${
            phase.learnerActivity ||
            phase.teacherActivity ||
            ""
          }`
      )
      .filter(Boolean)
      .join("\n") ||
    "Learners participate in guided inquiry, group discussion, observation, practical activity, explanation and presentation of findings.";

  const conclusion =
    "Learners summarise the main ideas while the teacher clarifies misconceptions and reinforces the key concepts.";

  const extended =
    lessonPlan.homework ||
    "Learners complete an extended activity or assignment related to the lesson.";

  const lessonDuration = lessonPlan.durationMinutes || 40;
  const filename = `professional-lesson-plan-${lessonPlan._id}.docx`;

  const filePath = path.join(
    ensureExportDir(),
    filename
  );

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: 720,
              right: 720,
              bottom: 720,
              left: 720
            }
          }
        },

        children: [
          new Paragraph({
            alignment:
              AlignmentType.CENTER,

            children: [
              new TextRun({
                text:
                  "GRADE 10 BIOLOGY LESSON PLAN",
                bold: true,
                size: 30
              })
            ]
          }),

          new Paragraph(""),

          new Table({
            width: {
              size: 100,
              type:
                WidthType.PERCENTAGE
            },

            borders: tableBorders,

            rows: [
              new TableRow({
                children: [
                  infoCell("School", ""),
                  infoCell("Teacher", ""),
                  infoCell("TSC No", "")
                ]
              }),

              new TableRow({
                children: [
                  infoCell(
                    "Term",
                    lessonPlan.termNumber
                  ),

                  infoCell(
                    "Week",
                    lessonPlan.weekNumber
                  ),

                  infoCell(
                  "Lesson",
                  lessonPlan.durationMinutes >= 80
                    ? `${lessonPlan.lessonNumber} & ${Number(lessonPlan.lessonNumber) + 1}`
                    : lessonPlan.lessonNumber
                  )

                ]
              }),

              new TableRow({
                children: [
                  infoCell(
                    "Subject",
                    lessonPlan.subject ||
                      "Biology"
                  ),

                  infoCell(
                    "Grade",
                    lessonPlan.grade || "10"
                  ),

                  infoCell(
                    "Duration",
                    `${lessonDuration} minutes`
                  )
                ]
              }),

              new TableRow({
                children: [
                  infoCell("Date", ""),
                  infoCell("Time", ""),
                  infoCell("Number of Learners", lessonPlan.numberOfLearners || "")
                ]
              })
            ]
          }),
          new Paragraph(""),

          new Table({
            width: {
              size: 100,
              type: WidthType.PERCENTAGE
            },

            borders: tableBorders,

            rows: [
              sectionHeader(
                "CURRICULUM DETAILS",
                2
              ),

              new TableRow({
                children: [
                  textCell(
                    "Topic / Lesson Title",
                    30,
                    true
                  ),

                  textCell(
                    lessonPlan.lessonTitle ||
                      "Biology Lesson",
                    70
                  )
                ]
              }),

              new TableRow({
                children: [
                  textCell(
                    "Strand",
                    30,
                    true
                  ),

                  textCell(
                    lessonPlan.strand || "",
                    70
                  )
                ]
              }),

              new TableRow({
                children: [
                  textCell(
                    "Sub-strand",
                    30,
                    true
                  ),

                  textCell(
                    lessonPlan.subStrand ||
                      "",
                    70
                  )
                ]
              }),

              new TableRow({
                children: [
                  textCell(
                    "Specific Learning Outcomes",
                    30,
                    true
                  ),

                  textCell(
                    learningOutcomes,
                    70
                  )
                ]
              }),

              new TableRow({
                children: [
                  textCell(
                    "Key Inquiry Question(s)",
                    30,
                    true
                  ),

                  textCell(
                    lessonPlan.keyInquiryQuestion ||
                      "",
                    70
                  )
                ]
              })
            ]
          }),

          new Paragraph(""),

          new Table({
            width: {
              size: 100,
              type: WidthType.PERCENTAGE
            },

            borders: tableBorders,

            rows: [
              sectionHeader(
                "COMPETENCY FOCUS",
                3
              ),

              new TableRow({
                children: [
                  headerCell(
                    "Core Competencies",
                    34
                  ),

                  headerCell(
                    "Values",
                    33
                  ),

                  headerCell(
                    "PCIs / Life Skills",
                    33
                  )
                ]
              }),

              new TableRow({
                children: [
                  textCell(
                    "Communication and Collaboration\nCritical Thinking and Problem Solving\nLearning to Learn\nDigital Literacy",
                    34
                  ),

                  textCell(
                    "Responsibility\nRespect\nIntegrity\nExcellence",
                    33
                  ),

                  textCell(
                    "Environmental Awareness\nHealth Education\nDigital Citizenship\nSafety and Security",
                    33
                  )
                ]
              })
            ]
          }),

          new Paragraph(""),

          new Table({
            width: {
              size: 100,
              type: WidthType.PERCENTAGE
            },

            borders: tableBorders,

            rows: [
              sectionHeader(
                "ORGANIZATION OF LEARNING",
                6
              ),

              new TableRow({
                children: [
                  headerCell("Time", 10),
                  headerCell(
                    "Lesson Phase",
                    15
                  ),
                  headerCell(
                    "Learning Experiences",
                    35
                  ),
                  headerCell(
                    "Learning Resources",
                    15
                  ),
                  headerCell(
                    "Phase Assessment Method",
                    15
                  ),
                  headerCell(
                    "Reflection",
                    10
                  )
                ]
              }),

              new TableRow({
                children: [
                  textCell("5 min", 10),
                  textCell(
                    "Introduction",
                    15,
                    true
                  ),
                  textCell(intro, 35),
                  textCell(
                    resources ||
                      "Charts\nDigital devices\nSpecimens",
                    15
                  ),
                  textCell(
                    "Oral questioning\nObservation",
                    15
                  ),
                  textCell("", 10)
                ]
              }),

              new TableRow({
                children: [
                  textCell(lessonDuration >= 80 ? "65 min" : "25 min", 10),
                  textCell(
                    "Development",
                    15,
                    true
                  ),
                  textCell(
                    development,
                    35
                  ),
                  textCell(
                    resources ||
                      "Textbooks\nCharts\nLaboratory apparatus\nDigital media",
                    15
                  ),
                  textCell(
                    "Group work\nPresentation\nTeacher observation\nWritten task",
                    15
                  ),
                  textCell("", 10)
                ]
              }),

              new TableRow({
                children: [
                  textCell("5 min", 10),
                  textCell(
                    "Conclusion",
                    15,
                    true
                  ),
                  textCell(
                    conclusion,
                    35
                  ),
                  textCell(
                    "Learner responses\nBoard summary",
                    15
                  ),
                  textCell(
                    "Question and answer\nExit response",
                    15
                  ),
                  textCell("", 10)
                ]
              }),

              new TableRow({
                children: [
                  textCell("", 10),
                  textCell(
                    "Extended Activities / Assignment",
                    15,
                    true
                  ),
                  textCell(
                    extended,
                    35
                  ),
                  textCell(
                    "Learner book\nDigital resources\nHome environment",
                    15
                  ),
                  textCell(
                    "Assignment review",
                    15
                  ),
                  textCell("", 10)
                ]
              }),

              new TableRow({
                children: [
                  textCell("Integrated", 10),
                  textCell(
                    "Assessment",
                    15,
                    true
                  ),
                  textCell(
                    assessment ||
                      "Learners respond to oral questions, complete a short written task and participate in observation-based assessment.",
                    35
                  ),
                  textCell(
                    "Assessment tools\nChecklist\nExercise books",
                    15
                  ),
                  textCell(
                    "Oral questions\nObservation\nWritten exercise\nPortfolio evidence",
                    15
                  ),
                  textCell("", 10)
                ]
              })
            ]
          }),
                    new Paragraph(""),

          new Table({
            width: {
              size: 100,
              type: WidthType.PERCENTAGE
            },

            borders: tableBorders,

            rows: [
              sectionHeader(
                "TEACHER SELF-EVALUATION",
                1
              ),

              new TableRow({
                children: [
                  new TableCell({
                    children: [
                      new Paragraph(
                        "..........................................................................................................................................................................................................................................................................................................................................................................................................."
                      ),

                      new Paragraph(
                        "..........................................................................................................................................................................................................................................................................................................................................................................................................."
                      )
                    ]
                  })
                ]
              })
            ]
          }),

          new Paragraph(""),

          new Table({
            width: {
              size: 100,
              type: WidthType.PERCENTAGE
            },

            borders: tableBorders,

            rows: [
              sectionHeader(
                "VALIDATION",
                3
              ),

              new TableRow({
                children: [
                  textCell(
                    "Checked by HOD / Deputy Principal:\nSignature: ____________________\nDate: ____________________",
                    33
                  ),

                  textCell(
                    "Approved by Principal:\nSignature: ____________________\nDate: ____________________",
                    33
                  ),

                  textCell(
                    "School Stamp:\n\n\n",
                    34
                  )
                ]
              })
            ]
          })
        ]
      }
    ]
  });

  const buffer =
    await Packer.toBuffer(doc);

  fs.writeFileSync(
    filePath,
    buffer
  );

  return {
    filename,
    filePath
  };
}

export async function exportLessonPlanToPdf(
  lessonPlan
) {
  return savePdf(
    `lesson-plan-${lessonPlan._id}.pdf`,
    (doc) => {
      doc
        .fontSize(18)
        .text(
          "WhiteboardHub AI Curriculum Studio",
          {
            align: "center"
          }
        );

      doc.moveDown();

      doc
        .fontSize(16)
        .text(
          lessonPlan.lessonTitle ||
            "Lesson Plan",
          {
            underline: true
          }
        );

      doc.moveDown();

      doc
        .fontSize(11)
        .text(
          `Subject: ${
            lessonPlan.subject || ""
          }`
        );

      doc.text(
        `Grade: ${
          lessonPlan.grade || ""
        }`
      );

      doc.text(
        `Term ${
          lessonPlan.termNumber || ""
        }, Week ${
          lessonPlan.weekNumber || ""
        }, Lesson ${
          lessonPlan.lessonNumber || ""
        }`
      );

      doc.text(
        `Duration: ${
          lessonPlan.durationMinutes ||
          40
        } minutes`
      );

      doc.text(
        `Strand: ${
          lessonPlan.strand || ""
        }`
      );

      doc.text(
        `Sub-strand: ${
          lessonPlan.subStrand || ""
        }`
      );

      doc.moveDown();

      writePdfList(
        doc,
        "Learning Outcomes",
        lessonPlan.learningOutcomes
      );

      writePdfSection(
        doc,
        "Key Inquiry Question",
        lessonPlan.keyInquiryQuestion
      );

      writePdfList(
        doc,
        "Learning Resources",
        lessonPlan.learningResources
      );

      writePdfSection(
        doc,
        "Introduction",
        lessonPlan.introduction
      );
    }
  );
}

/* =========================
   LESSON PACKAGE EXPORTS
========================= */

export async function exportLessonPackageToWord(lessonPackage) {
  const notes = lessonPackage.teacherNotesSections || {};
  const learner = lessonPackage.learnerNotesSections || {};

  function sectionTitle(text) {
    return new Paragraph({
      children: [new TextRun({ text, bold: true, size: 24 })]
    });
  }

  function listItems(items = []) {
    return items.map((item) => bullet(item));
  }

  const children = [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({
          text: "PROFESSIONAL LESSON PACKAGE",
          bold: true,
          size: 30
        })
      ]
    }),

    new Paragraph(""),

    sectionTitle("A. TEACHER NOTES"),

    p(`Topic: ${notes.topic || ""}`),
    p(`Sub-topic: ${notes.subTopic || ""}`),

    sectionTitle("Key Concepts"),
    ...listItems(notes.keyConcepts || []),

    sectionTitle("Detailed Teacher Exposition"),
    p(notes.detailedTeacherExposition || lessonPackage.teacherNotes || ""),

    sectionTitle("Common Misconceptions"),
    ...listItems(notes.commonMisconceptions || []),

    sectionTitle("Teaching Hints"),
    ...listItems(notes.teachingHints || []),

    sectionTitle("Board Summary"),
    ...listItems(notes.boardSummary || []),

    sectionTitle("Learner Support and Remediation"),
    ...listItems(notes.learnerSupportAndRemediation || []),

    sectionTitle("Extension and Enrichment"),
    ...listItems(notes.extensionAndEnrichment || []),

    new Paragraph(""),

    sectionTitle("B. LEARNER NOTES"),

    p(`Topic: ${learner.topic || ""}`),

    sectionTitle("Key Terms"),
    ...listItems(learner.keyTerms || []),

    sectionTitle("Simple Explanation"),
    p(learner.simpleExplanation || lessonPackage.learnerNotes || ""),

    sectionTitle("Examples"),
    ...listItems(learner.examples || []),

    sectionTitle("Diagram / Illustration Prompts"),
    ...listItems(learner.diagramPrompts || []),

    sectionTitle("Quick Check Questions"),
    ...listItems(learner.quickCheckQuestions || []),

    sectionTitle("Summary"),
    ...listItems(learner.summary || []),

    sectionTitle("Assignment"),
    p(learner.assignment || lessonPackage.homework || ""),

    new Paragraph(""),

    sectionTitle("C. LEARNING EXPERIENCES"),
    ...listItems(lessonPackage.learningExperiences || []),

    new Paragraph(""),

    sectionTitle("D. ASSESSMENT ITEMS"),
    ...(lessonPackage.assessmentItems || []).map((item, index) =>
      p(
        `${index + 1}. ${item.question || ""} ` +
        `(${item.marks || ""} marks)\nExpected Answer: ${item.expectedAnswer || ""}`
      )
    ),

    new Paragraph(""),

    sectionTitle("E. CBC RUBRIC"),

    new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      borders: tableBorders,
      rows: [
        new TableRow({
          children: [
            headerCell("Level", 20),
            headerCell("Descriptor", 80)
          ]
        }),

        ...(lessonPackage.rubric || []).map((item) =>
          new TableRow({
            children: [
              cell(item.level || "", 20, true),
              cell(item.descriptor || "", 80)
            ]
          })
        )
      ]
    }),

    new Paragraph(""),

    sectionTitle("F. HOMEWORK / EXTENDED ACTIVITY"),
    p(lessonPackage.homework || ""),

    new Paragraph(""),

    sectionTitle("G. LEARNING RESOURCES"),
    ...listItems(lessonPackage.resources || [])
  ];

  const filename = `professional-lesson-package-${lessonPackage._id}.docx`;
  const filePath = path.join(ensureExportDir(), filename);

  const doc = new Document({
    sections: [{ children }]
  });

  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync(filePath, buffer);

  return { filename, filePath };
}
  
export async function exportLessonPackageToPdf(lessonPackage) {
  return savePdf(`lesson-package-${lessonPackage._id}.pdf`, (doc) => {
    const notes = lessonPackage.teacherNotesSections || {};

    doc.fontSize(18).text("PROFESSIONAL LESSON PACKAGE", {
      align: "center"
    });

    doc.moveDown();

    doc.fontSize(14).text("A. TEACHER NOTES", { underline: true });
    doc.moveDown(0.5);

    if (notes.topic) doc.fontSize(11).text(`Topic: ${notes.topic}`);
    if (notes.subTopic) doc.fontSize(11).text(`Sub-topic: ${notes.subTopic}`);

    writePdfList(doc, "Key Concepts", notes.keyConcepts || []);
    writePdfSection(
      doc,
      "Detailed Teacher Exposition",
      notes.detailedTeacherExposition || lessonPackage.teacherNotes
    );
    writePdfList(doc, "Common Misconceptions", notes.commonMisconceptions || []);
    writePdfList(doc, "Teaching Hints", notes.teachingHints || []);
    writePdfList(doc, "Board Summary", notes.boardSummary || []);
    writePdfList(doc, "Learner Support and Remediation", notes.learnerSupportAndRemediation || []);
    writePdfList(doc, "Extension and Enrichment", notes.extensionAndEnrichment || []);

    writePdfSection(doc, "B. LEARNER NOTES", lessonPackage.learnerNotes);
    writePdfList(doc, "C. LEARNING EXPERIENCES", lessonPackage.learningExperiences || []);

    doc.fontSize(14).text("D. ASSESSMENT ITEMS", { underline: true });
    doc.moveDown(0.5);

    (lessonPackage.assessmentItems || []).forEach((item, index) => {
      doc.fontSize(11).text(`${index + 1}. ${item.question || ""} (${item.marks || ""} marks)`);
      doc.text(`Expected Answer: ${item.expectedAnswer || ""}`);
      doc.moveDown(0.5);
    });

    writePdfList(
      doc,
      "E. CBC RUBRIC",
      (lessonPackage.rubric || []).map(
        (item) => `${item.level || ""}: ${item.descriptor || ""}`
      )
    );

    writePdfSection(doc, "F. HOMEWORK / EXTENDED ACTIVITY", lessonPackage.homework);
    writePdfList(doc, "G. LEARNING RESOURCES", lessonPackage.resources || []);
  });
}

export async function exportRecordOfWorkToWord(record) {
  const filename = `record-of-work-${record._id}.docx`;
  const filePath = path.join(ensureExportDir(), filename);

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            size: { orientation: PageOrientation.LANDSCAPE },
            margin: { top: 720, right: 720, bottom: 720, left: 720 }
          }
        },
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: "RECORD OF WORK",
                bold: true,
                size: 30
              })
            ]
          }),

          new Paragraph(""),

          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            borders: tableBorders,
            rows: [
              new TableRow({
                children: [
                  cell("School: ................................................", 50),
                  cell("Teacher: ................................................", 50)
                ]
              }),
              new TableRow({
                children: [
                  cell(`Subject: ${record.subject || ""}`, 50),
                  cell(`Grade/Class: ${record.grade || ""}`, 50)
                ]
              }),
              new TableRow({
                children: [
                  cell(`Term: ${record.termNumber || ""}`, 50),
                  cell(`Week: ${record.weekNumber || ""}`, 50)
                ]
              })
            ]
          }),

          new Paragraph(""),

          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            borders: tableBorders,
            rows: [
              new TableRow({
                children: [
                  headerCell("Date", 10),
                  headerCell("Lesson / Period", 12),
                  headerCell("Strand", 15),
                  headerCell("Sub-strand", 18),
                  headerCell("Work Covered", 30),
                  headerCell("Reference", 15),
                  headerCell("Remarks", 10)
                ]
              }),

              new TableRow({
                children: [
                  cell(record.date || "", 10),
                  cell(record.lessonNumber || record.period || "", 12),
                  cell(record.strand || "", 15),
                  cell(record.subStrand || "", 18),
                  cell(record.workCovered || "", 30),
                  cell(record.reference || "", 15),
                  cell(record.remarks || "", 10)
                ]
              })
            ]
          }),

          new Paragraph(""),

          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            borders: tableBorders,
            rows: [
              new TableRow({
                children: [
                  cell("Teacher's Signature: __________________________ Date: ______________", 50),
                  cell("Checked by HOD / Deputy Principal: __________________________ Date: ______________", 50)
                ]
              })
            ]
          })
        ]
      }
    ]
  });

  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync(filePath, buffer);

  return { filename, filePath };
}

export async function exportRecordOfWorkToPdf(record) {
  return savePdf(`record-of-work-${record._id}.pdf`, (doc) => {
    doc.fontSize(18).text("RECORD OF WORK", { align: "center" });
    doc.moveDown();

    doc.fontSize(11).text(`Subject: ${record.subject || ""}`);
    doc.text(`Grade: ${record.grade || ""}`);
    doc.text(`Term: ${record.termNumber || ""}`);
    doc.text(`Week: ${record.weekNumber || ""}`);
    doc.text(`Lesson / Period: ${record.lessonNumber || record.period || ""}`);
    doc.moveDown();

    writePdfSection(doc, "Strand", record.strand);
    writePdfSection(doc, "Sub-strand", record.subStrand);
    writePdfSection(doc, "Work Covered", record.workCovered);
    writePdfSection(doc, "Reference", record.reference);
    writePdfSection(doc, "Remarks", record.remarks);
  });
}