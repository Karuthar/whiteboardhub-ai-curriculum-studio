export default {

    id: "scheme",

    title: "Scheme of Work",

    orientation: "landscape",

    paper: "A4",

    builder: "./builder.js",

    template: "./template.js",

    validator: "./validator.js"

};