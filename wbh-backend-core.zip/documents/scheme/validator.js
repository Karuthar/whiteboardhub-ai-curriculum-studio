export function validateScheme(data) {

    if (!data)
        throw new Error("Scheme missing.");

    if (!data.terms)
        throw new Error("Terms missing.");

    return true;

}