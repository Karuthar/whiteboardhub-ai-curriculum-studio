export function generateSchemeOfWork(curriculum) {
  const strands = curriculum.structuredCurriculum?.strands || [];

  const termsConfig = [
    { termNumber: 1, numberOfWeeks: 13 },
    { termNumber: 2, numberOfWeeks: 14 },
    { termNumber: 3, numberOfWeeks: 9 }
  ];

  const allSubStrands = [];

  strands.forEach((strand) => {
    strand.subStrands.forEach((subStrand) => {
      allSubStrands.push({
        strand: strand.strandTitle,
        subStrand: subStrand.subStrandTitle,
        outcomes: subStrand.specificLearningOutcomes,
        experiences: subStrand.suggestedLearningExperiences,
        assessment: subStrand.suggestedAssessment
      });
    });
  });

  let subStrandIndex = 0;

  const terms = termsConfig.map((term) => {
    const weeks = [];

    for (let week = 1; week <= term.numberOfWeeks; week++) {
      const lessons = [];

      if ((term.termNumber === 1 || term.termNumber === 2) && week === 8) {
        lessons.push({
          lessonNumber: 1,
          lessonTitle: "Midterm Examinations",
          remarks: "Lessons 1-5 reserved for midterm examinations"
        });
      } else if (week === term.numberOfWeeks) {
        lessons.push({
          lessonNumber: 1,
          lessonTitle: "End Term Examinations",
          remarks: "Lessons 1-5 reserved for end term examinations"
        });
      } else {
        for (let lesson = 1; lesson <= 5; lesson++) {
          const current = allSubStrands[subStrandIndex % allSubStrands.length];

          lessons.push({
            lessonNumber: lesson,
            strand: current.strand,
            subStrand: current.subStrand,
            lessonTitle: `${current.subStrand} - Lesson ${lesson}`,
            learningOutcomes: current.outcomes,
            learningExperiences: current.experiences,
            resources: [
              "Curriculum design",
              "Teacher guide",
              "Learner textbook",
              "Charts",
              "Digital devices",
              "Locally available materials"
            ],
            assessment: current.assessment,
            remarks: ""
          });
        }

        subStrandIndex++;
      }

      weeks.push({ weekNumber: week, lessons });
    }

    return {
      termNumber: term.termNumber,
      numberOfWeeks: term.numberOfWeeks,
      weeks
    };
  });

  return {
    title: `${curriculum.subject} Grade ${curriculum.grade} Scheme of Work`,
    grade: curriculum.grade,
    subject: curriculum.subject,
    academicYear: "2025",
    lessonsPerWeek: 5,
    lessonDurationMinutes: 40,
    terms
  };
}