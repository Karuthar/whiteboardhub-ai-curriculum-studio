import SchemeOfWork from "../models/schemeOfWork.model.js";
import LessonPlan from "../models/lessonPlan.model.js";
import { generateLessonPlanFromSchemeLesson } from "../services/lessonPlanGenerator.service.js";

export async function generateLessonPlan(req, res) {
  try {
    const { schemeId } = req.params;

    const {
      termNumber,
      weekNumber,
      lessonNumber,
      durationMinutes
    } = req.body;

    const scheme = await SchemeOfWork.findById(schemeId);

    if (!scheme) {
      return res.status(404).json({
        success: false,
        message: "Scheme of work not found"
      });
    }

    const lessonPlanData = await generateLessonPlanFromSchemeLesson({
      scheme,
      termNumber,
      weekNumber,
      lessonNumber,
      durationMinutes: durationMinutes || 40
    });

    const lessonPlan = await LessonPlan.create({
  schemeId: scheme._id,
  curriculumId: scheme.curriculumId,
  ...lessonPlanData,
  durationMinutes: durationMinutes || lessonPlanData.durationMinutes || 40
});
    res.status(201).json({
      success: true,
      message: "Lesson plan generated successfully",
      lessonPlan
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to generate lesson plan",
      error: error.message
    });
  }
}

export async function getLessonPlans(req, res) {
  try {
    const lessonPlans = await LessonPlan.find()
      .populate("schemeId")
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      count: lessonPlans.length,
      lessonPlans
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch lesson plans",
      error: error.message
    });
  }
}

export async function deleteLessonPlan(req, res) {
  try {
    const { lessonPlanId } = req.params;

    await LessonPlan.findByIdAndDelete(lessonPlanId);

    res.json({
      success: true,
      message: "Lesson plan deleted successfully"
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to delete lesson plan",
      error: error.message
    });
  }
}