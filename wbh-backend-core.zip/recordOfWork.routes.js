import express from "express";

import {
  generateRecordOfWork,
  getRecordsOfWork,
  getRecordOfWorkById,
  deleteRecordOfWork
} from "../controllers/recordOfWork.controller.js";

const router = express.Router();

router.get("/", getRecordsOfWork);
router.get("/:recordId", getRecordOfWorkById);
router.post("/lesson-plan/:lessonPlanId/generate", generateRecordOfWork);
router.delete("/:recordId", deleteRecordOfWork);

export default router;