import express from "express";

import {
  exportCustomHtmlDocx
} from "../controllers/exportCustomHtml.controller.js";

const router = express.Router();

router.post(
  "/custom-html-docx",
  exportCustomHtmlDocx
);

export default router;