import {
extractCurriculum
} from "../ai/curriculumExtractor.js";

import {
normalizeCurriculum
} from "../normalizer/curriculumNormalizer.js";

import {
validateCurriculum
} from "../validator/curriculumValidator.js";

export async function processCurriculum(rawText) {

const extraction =
await extractCurriculum(rawText);

const normalized =
normalizeCurriculum(
extraction.curriculum
);

const validation =
validateCurriculum(
normalized
);

return {

classification:
extraction.classification,

curriculum:
normalized,

validation

};

}