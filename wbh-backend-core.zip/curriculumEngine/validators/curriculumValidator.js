/**
 * WhiteboardHub AI Curriculum Studio
 * Curriculum Validator
 */

export function validateCurriculum(curriculum) {

  const errors = [];

  if (!curriculum) {
    errors.push("Curriculum not found.");
  }

  if (!curriculum?.metadata?.subject) {
    errors.push("Subject missing.");
  }

  if (!curriculum?.metadata?.grade) {
    errors.push("Grade missing.");
  }

  if (!curriculum?.strands?.length) {
    errors.push("No strands found.");
  }

  curriculum?.strands?.forEach((strand, strandIndex) => {

    if (!strand.title) {

      errors.push(
        `Strand ${strandIndex + 1} has no title.`
      );

    }

    if (!strand.subStrands?.length) {

      errors.push(
        `Strand "${strand.title}" contains no sub-strands.`
      );

    }

    strand.subStrands?.forEach((sub, subIndex) => {

      if (!sub.title) {

        errors.push(
          `Sub-strand ${subIndex + 1} has no title.`
        );

      }

      if (!sub.outcomes?.length) {

        errors.push(
          `"${sub.title}" has no learning outcomes.`
        );

      }

      if (!sub.learningExperiences?.length) {

        errors.push(
          `"${sub.title}" has no learning experiences.`
        );

      }

    });

  });

  return {

    valid:

      errors.length === 0,

    errors

  };

}