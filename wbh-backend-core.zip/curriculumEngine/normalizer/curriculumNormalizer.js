/**
 * WhiteboardHub AI Curriculum Studio
 * Curriculum Normalizer
 *
 * Converts any curriculum into the
 * Whiteboard Standard Curriculum Model (WSCM)
 */

export function normalizeCurriculum(curriculum = {}) {

  return {

    metadata: {

      curriculumName:
        curriculum.curriculumName ||
        "",

      country:
        curriculum.country ||
        "",

      educationSystem:
        curriculum.educationSystem ||
        "",

      grade:
        curriculum.grade ||
        "",

      subject:
        curriculum.subject ||
        "",

      academicYear:
        curriculum.academicYear ||
        ""

    },

    strands:

      normalizeStrands(
        curriculum.structuredCurriculum?.strands ||
        curriculum.strands ||
        []
      )

  };

}

function normalizeStrands(strands = []) {

  return strands.map(strand => ({

    id:

      strand.id ||

      crypto.randomUUID(),

    title:

      strand.strandTitle ||

      strand.title ||

      "",

    description:

      strand.description ||

      "",

    subStrands:

      normalizeSubStrands(

        strand.subStrands ||

        []

      )

  }));

}

function normalizeSubStrands(subStrands = []) {

  return subStrands.map(sub => ({

    id:

      sub.id ||

      crypto.randomUUID(),

    title:

      sub.subStrandTitle ||

      sub.title ||

      "",

    outcomes:

      sub.specificLearningOutcomes ||

      sub.learningOutcomes ||

      [],

    learningExperiences:

      sub.suggestedLearningExperiences ||

      [],

    assessment:

      sub.suggestedAssessment ||

      [],

    resources:

      sub.resources ||

      [],

    values:

      sub.values ||

      [],

    competencies:

      sub.coreCompetencies ||

      [],

    pcis:

      sub.PCIs ||

      [],

    keyInquiryQuestions:

      sub.keyInquiryQuestions ||

      []

  }));

}