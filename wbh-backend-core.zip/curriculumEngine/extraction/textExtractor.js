export async function extractText(file) {

    switch (file.type) {

        case "pdf":
            break;

        case "docx":
            break;

        case "html":
            break;

        case "txt":
            break;

        case "image":
            break;

        default:
            throw new Error("Unsupported file");

    }

}