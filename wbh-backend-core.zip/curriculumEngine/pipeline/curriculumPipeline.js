import {
  normalizeCurriculum
} from "../normalizer/curriculumNormalizer.js";

import {
  validateCurriculum
} from "../validator/curriculumValidator.js";

export function processCurriculum(rawCurriculum) {

  const normalized =
    normalizeCurriculum(rawCurriculum);

  const validation =
    validateCurriculum(normalized);

  return {

    curriculum:
      normalized,

    validation

  };

}