import client from "./aiClient.js";

export async function classifyCurriculum(text) {

  const prompt = `
Determine:

1 Education System
2 Document Type
3 Subject
4 Grade

Return ONLY JSON.

TEXT:

${text}
`;

  const response =
    await client.responses.create({

      model: process.env.AI_MODEL,

      input: prompt

    });

  return JSON.parse(
    response.output_text
  );

}