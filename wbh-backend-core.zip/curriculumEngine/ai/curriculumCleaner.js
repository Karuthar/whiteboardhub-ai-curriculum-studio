export function cleanCurriculumText(text = "") {

  return text

    .replace(/\r/g, "")

    .replace(/\t/g, " ")

    .replace(/[ ]{2,}/g, " ")

    .replace(/\n{3,}/g, "\n\n")

    .trim();

}