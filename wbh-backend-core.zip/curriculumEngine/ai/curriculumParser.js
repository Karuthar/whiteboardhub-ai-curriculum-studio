import client from "./aiClient.js";

export async function parseCurriculum(text) {

const prompt = `

Extract ALL curriculum information.

Return ONLY valid JSON.

Structure:

{

subject,

grade,

curriculumName,

strands:[

{

title,

subStrands:[

{

title,

learningOutcomes,

learningExperiences,

assessment,

resources,

values,

coreCompetencies,

PCIs,

keyInquiryQuestions

}

]

}

]

}

TEXT:

${text}

`;

const response =
await client.responses.create({

model:
process.env.AI_MODEL,

input:
prompt

});

return JSON.parse(
response.output_text
);

}