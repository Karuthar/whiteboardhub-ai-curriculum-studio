import {
cleanCurriculumText
} from "./curriculumCleaner.js";

import {
classifyCurriculum
} from "./curriculumClassifier.js";

import {
parseCurriculum
} from "./curriculumParser.js";

export async function extractCurriculum(rawText) {

const cleaned =
cleanCurriculumText(rawText);

const classification =
await classifyCurriculum(cleaned);

const parsed =
await parseCurriculum(cleaned);

return {

classification,

curriculum:
parsed

};

}