import fs from "fs";
import path from "path";
import mammoth from "mammoth";
import * as pdfParseModule from "pdf-parse";

export function detectResourceType(mimeType = "", fileName = "") {
  const ext = path.extname(fileName).toLowerCase();

  if (mimeType.startsWith("image/")) return "image";
  if (mimeType.startsWith("video/")) return "video";

  if (mimeType === "application/pdf" || ext === ".pdf") return "pdf";

  if (
    mimeType.includes("wordprocessingml") ||
    ext === ".docx"
  ) {
    return "docx";
  }

  if (
    mimeType.includes("text") ||
    ext === ".txt" ||
    ext === ".doc"
  ) {
    return "document";
  }

  return "other";
}

export async function extractResourceText(filePath, resourceType) {
  try {
    if (resourceType === "docx") {
      const result = await mammoth.extractRawText({ path: filePath });
      return result.value || "";
    }

    if (resourceType === "pdf") {
      const buffer = fs.readFileSync(filePath);

      const pdfParse =
  pdfParseModule.default ||
  pdfParseModule.pdfParse ||
  pdfParseModule;

    const result = await pdfParse(buffer);
    
      return result.text || "";
    }

    if (resourceType === "document") {
      return fs.readFileSync(filePath, "utf-8");
    }

    return "";
  } catch (error) {
    console.log("Resource extraction failed:", error.message);
    return "";
  }
}

export function buildPreviewUrl(fileName) {
  return `/uploads/resources/${fileName}`;
}