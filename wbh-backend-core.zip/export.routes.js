import express from "express";

import {
  exportLessonPackageDocx,
  exportLessonPackagePdf,
  exportLessonPlanDocx,
  exportLessonPlanPdf,
  exportSchemeDocx,
  exportSchemePdf,
  exportRecordOfWorkDocx,
  exportRecordOfWorkPdf
} from "../controllers/export.controller.js";

const router = express.Router();

router.get("/scheme/:schemeId/docx", exportSchemeDocx);
router.get("/scheme/:schemeId/pdf", exportSchemePdf);

router.get("/lesson-plan/:lessonPlanId/docx", exportLessonPlanDocx);
router.get("/lesson-plan/:lessonPlanId/pdf", exportLessonPlanPdf);

router.get("/lesson-package/:lessonPackageId/docx", exportLessonPackageDocx);
router.get("/lesson-package/:lessonPackageId/pdf", exportLessonPackagePdf);

router.get("/record-of-work/:recordId/docx", exportRecordOfWorkDocx);
router.get("/record-of-work/:recordId/pdf", exportRecordOfWorkPdf);

export default router;