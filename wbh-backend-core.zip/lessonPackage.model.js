import mongoose from "mongoose";

const lessonPackageSchema = new mongoose.Schema(
  {
    lessonPlanId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "LessonPlan",
      required: true
    },
    schemeId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "SchemeOfWork"
    },
    curriculumId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Curriculum"
    },
    teacherNotes: String,
    learnerNotes: String,
    learningExperiences: [String],
    assessmentItems: [
      {
        question: String,
        expectedAnswer: String,
        marks: Number
      }
    ],
    rubric: [
      {
        level: String,
        descriptor: String
      }
    ],
    homework: String,
    resources: [String],
    generatedBy: {
      type: String,
      enum: ["fallback", "ai"],
      default: "fallback"
    }
  },
  { timestamps: true }
);

export default mongoose.model("LessonPackage", lessonPackageSchema);
