export function parseCurriculumText(rawText = "") {
  return {
    strands: [
      {
        strandNumber: "1.0",
        strandTitle: "Cell Biology and Biodiversity",
        subStrands: [
          {
            subStrandNumber: "1.3",
            subStrandTitle: "Cell Structure and Specialisation",
            specificLearningOutcomes: [
              "Differentiate between light and electron microscope as used in the study of cell structure.",
              "Prepare temporary slides for observation and estimation of cell size using a light microscope.",
              "Describe the structure and functions of plant and animal cells.",
              "Relate specialised cell structures to their functions in living things.",
              "Appreciate the cell as the basic unit of life."
            ],
            suggestedLearningExperiences: [
              "Search for information using print and non-print media.",
              "Compare light and electron microscopes.",
              "Prepare temporary slides and observe cells under a microscope.",
              "Draw and label plant and animal cells.",
              "Discuss specialised cells and relate them to their functions."
            ],
            keyInquiryQuestions: [
              "Why do plant and animal cells differ?",
              "How are cells specialised?"
            ],
            coreCompetencies: [
              "Communication and Collaboration",
              "Digital Literacy"
            ],
            values: [
              "Respect",
              "Responsibility"
            ],
            pcis: [
              "Safety and Security",
              "Waste Management"
            ],
            suggestedAssessment: [
              "Observation checklist",
              "Practical task",
              "Labelled diagrams",
              "Oral questioning"
            ]
          }
        ]
      }
    ]
  };
}
