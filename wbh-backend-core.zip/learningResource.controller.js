import fs from "fs";
import LearningResource from "../models/learningResource.model.js";

import {
  detectResourceType,
  extractResourceText,
  buildPreviewUrl
} from "../services/learningResourceExtractor.service.js";

export async function uploadLearningResource(req, res) {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "No resource file uploaded"
      });
    }

    const resourceType = detectResourceType(
      req.file.mimetype,
      req.file.originalname
    );

    const extractedText = await extractResourceText(
      req.file.path,
      resourceType
    );

    const resource = await LearningResource.create({
      title: req.body.title || req.file.originalname,
      originalFileName: req.file.originalname,
      storedFileName: req.file.filename,
      filePath: req.file.path,
      mimeType: req.file.mimetype,
      resourceType,
      grade: req.body.grade || "",
      subject: req.body.subject || "",
      topic: req.body.topic || "",
      subTopic: req.body.subTopic || "",
      extractedText,
      previewUrl: buildPreviewUrl(req.file.filename),
      index: {
        type: "learningResource",
        gradeLevel: req.body.grade || "",
        learningArea: req.body.subject || "",
        resourceCategory: resourceType
      }
    });

    res.status(201).json({
      success: true,
      resource
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to upload learning resource",
      error: error.message
    });
  }
}

export async function getLearningResources(req, res) {
  try {
    const resources = await LearningResource.find()
      .sort({ createdAt: -1 })
      .limit(100);

    res.json({
      success: true,
      count: resources.length,
      resources
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch learning resources",
      error: error.message
    });
  }
}

export async function getLearningResourceById(req, res) {
  try {
    const resource = await LearningResource.findById(req.params.id);

    if (!resource) {
      return res.status(404).json({
        success: false,
        message: "Learning resource not found"
      });
    }

    res.json({
      success: true,
      resource
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch learning resource",
      error: error.message
    });
  }
}

export async function deleteLearningResource(req, res) {
  try {
    const resource = await LearningResource.findByIdAndDelete(req.params.id);

    if (!resource) {
      return res.status(404).json({
        success: false,
        message: "Learning resource not found"
      });
    }

    if (resource.filePath && fs.existsSync(resource.filePath)) {
      fs.unlinkSync(resource.filePath);
    }

    res.json({
      success: true,
      message: "Learning resource deleted"
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to delete learning resource",
      error: error.message
    });
  }
}