import mongoose from "mongoose";

const customDocumentSchema = new mongoose.Schema(
  {
    sourceDocumentId: {
      type: mongoose.Schema.Types.ObjectId,
      required: false,
      index: true
    },

    sourceData: {
  type: mongoose.Schema.Types.Mixed,
  default: null
},

    sourceDocumentType: {
      type: String,
      required: true,
      enum: [
        "curriculum",
        "scheme",
        "lessonPlan",
        "lessonNotes",
        "learningActivities",
        "assessment",
        "record",
        "resource"
      ],
      index: true
    },

    title: {
      type: String,
      required: true,
      trim: true
    },

    grade: {
      type: String,
      default: ""
    },

    subject: {
      type: String,
      default: ""
    },

    termNumber: {
      type: Number,
      default: null
    },

    weekNumber: {
      type: Number,
      default: null
    },

    lessonNumber: {
      type: Number,
      default: null
    },

    contentHtml: {
      type: String,
      required: true
    },

    contentText: {
      type: String,
      default: ""
    },

    documentData: {
      type: mongoose.Schema.Types.Mixed,
      default: {}
    },

    customizationMeta: {
      schoolName: { type: String, default: "" },
      teacherName: { type: String, default: "" },
      className: { type: String, default: "" },
      logoUrl: { type: String, default: "" },
      stampUrl: { type: String, default: "" }
    },

    insertedResources: [
      {
        resourceId: { type: String, default: "" },
        name: { type: String, default: "" },
        mimeType: { type: String, default: "" },
        url: { type: String, default: "" },
        insertedAt: { type: Date, default: Date.now }
      }
    ],

    index: {
      type: {
        type: String,
        default: "customDocument"
      },
      gradeLevel: {
        type: String,
        default: ""
      },
      learningArea: {
        type: String,
        default: ""
      },
      documentCategory: {
        type: String,
        default: ""
      }
    },

    status: {
      type: String,
      enum: ["draft", "customized", "final", "archived"],
      default: "draft",
      index: true
    }
  },
  {
    timestamps: true
  }
);

customDocumentSchema.index({
  sourceDocumentType: 1,
  grade: 1,
  subject: 1,
  termNumber: 1,
  weekNumber: 1,
  lessonNumber: 1
});

const CustomDocument = mongoose.model(
  "CustomDocument",
  customDocumentSchema
);

export default CustomDocument;

