import {

runBuilderPrompt

}

from "../ai/aiBuilder.js";

import {

schemePrompt

}

from "../prompts/scheme.prompt.js";

export async function buildScheme(

curriculum

){

const prompt=

schemePrompt(curriculum);

const response=

await runBuilderPrompt(prompt);

return JSON.parse(response);

}