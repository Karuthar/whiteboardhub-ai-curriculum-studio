import {
buildScheme
} from "../builders/scheme.builder.js";

import {
buildLessonPlan
} from "../builders/lessonPlan.builder.js";

import {
buildLearningActivities
} from "../builders/learningActivity.builder.js";

import {
buildLessonNotes
} from "../builders/lessonNotes.builder.js";

import {
buildAssessment
} from "../builders/assessment.builder.js";

import {
buildRevision
} from "../builders/revision.builder.js";

export const BuilderRegistry={

scheme:buildScheme,

lessonPlan:buildLessonPlan,

learningActivities:buildLearningActivities,

lessonNotes:buildLessonNotes,

assessment:buildAssessment,

revision:buildRevision

};