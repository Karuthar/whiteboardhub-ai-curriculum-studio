import client from "../../curriculumEngine/ai/aiClient.js";

export async function runBuilderPrompt(prompt){

const response=

await client.responses.create({

model:

process.env.AI_MODEL,

input:prompt

});

return response.output_text;

}