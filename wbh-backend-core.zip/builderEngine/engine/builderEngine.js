import {
BuilderRegistry
} from "../registry/builderRegistry.js";

export async function generateDocument({

type,

curriculum,

options={}

}){

const builder=

BuilderRegistry[type];

if(!builder){

throw new Error(

`Unknown builder: ${type}`

);

}

return builder(

curriculum,

options

);

}