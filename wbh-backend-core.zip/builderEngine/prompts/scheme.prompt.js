export function schemePrompt(curriculum){

return `

Generate a professional Scheme of Work.

Return ONLY JSON.

Curriculum:

${JSON.stringify(curriculum)}

`;

}