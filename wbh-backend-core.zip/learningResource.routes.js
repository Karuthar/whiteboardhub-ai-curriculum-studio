import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";

import {
  uploadLearningResource,
  getLearningResources,
  getLearningResourceById,
  deleteLearningResource
} from "../controllers/learningResource.controller.js";

const router = express.Router();

const uploadDir = path.join(process.cwd(), "uploads", "resources");

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination(req, file, cb) {
    cb(null, uploadDir);
  },

  filename(req, file, cb) {
    const safeName = file.originalname.replace(/[^a-zA-Z0-9.\-_]/g, "_");
    cb(null, `${Date.now()}-${safeName}`);
  }
});

const upload = multer({ storage });

router.post(
  "/upload",
  upload.single("resourceFile"),
  uploadLearningResource
);

router.get("/", getLearningResources);
router.get("/:id", getLearningResourceById);
router.delete("/:id", deleteLearningResource);

export default router;