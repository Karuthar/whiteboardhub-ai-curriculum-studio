import express from "express";

import {
  createCustomDocument,
  getCustomDocuments,
  getCustomDocumentById,
  updateCustomDocument,
  deleteCustomDocument,
  exportCustomDocumentDocx
} from "../controllers/customDocument.controller.js";

const router = express.Router();

router.post("/", createCustomDocument);
router.get("/", getCustomDocuments);
router.get("/:id/export/docx", exportCustomDocumentDocx);
router.get("/:id", getCustomDocumentById);
router.put("/:id", updateCustomDocument);
router.delete("/:id", deleteCustomDocument);

export default router;