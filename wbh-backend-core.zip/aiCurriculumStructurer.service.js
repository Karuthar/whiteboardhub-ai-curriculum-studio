import OpenAI from "openai";
import { parseCurriculumText } from "./curriculumParser.service.js";

export async function structureCurriculumWithAI(rawText = "") {
  if (!process.env.OPENAI_API_KEY) {
    console.log("OPENAI_API_KEY missing. Using fallback parser.");
    return parseCurriculumText(rawText);
  }

  try {
    const client = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY
    });

    const trimmedText = rawText.slice(0, 45000);

    const response = await client.responses.create({
      model: process.env.AI_MODEL || "gpt-5.5",
      input: `
You are an expert curriculum designer.

Extract the curriculum design below into valid JSON only.

Required JSON shape:
{
  "strands": [
    {
      "strandNumber": "string",
      "strandTitle": "string",
      "subStrands": [
        {
          "subStrandNumber": "string",
          "subStrandTitle": "string",
          "specificLearningOutcomes": ["string"],
          "suggestedLearningExperiences": ["string"],
          "keyInquiryQuestions": ["string"],
          "coreCompetencies": ["string"],
          "values": ["string"],
          "pcis": ["string"],
          "suggestedAssessment": ["string"]
        }
      ]
    }
  ]
}

Rules:
- Return JSON only.
- Do not add markdown.
- Preserve curriculum wording as much as possible.
- If a field is missing, use an empty array.
- Group content under correct strand and substrand.

CURRICULUM TEXT:
${trimmedText}
`
    });

    const parsed = JSON.parse(response.output_text);

    if (!parsed.strands || !Array.isArray(parsed.strands)) {
      throw new Error("AI response missing strands array.");
    }

    return parsed;
  } catch (error) {
    console.log("AI structuring failed. Using fallback parser.");
    console.log(error.message);
    return parseCurriculumText(rawText);
  }
}