import { extractTextFromUploadedFile } from "../services/ocrExtractor.service.js";
import Curriculum from "../models/curriculum.model.js";
import SchemeOfWork from "../models/schemeOfWork.model.js";
import { structureCurriculumWithAI } from "../services/aiCurriculumStructurer.service.js";
import { generateSchemeOfWork } from "../services/schemeGenerator.service.js";

export async function uploadCurriculum(req, res) {
    try {

        const {
            title,
            grade,
            subject,
            year,
            rawText
        } = req.body;

        let extractedText = rawText || "";
        let extractionMethod = "manual-text";

        if (req.file) {

            console.log("========== CURRICULUM UPLOAD ==========");
            console.log("FILE:", req.file.originalname);
            console.log("PATH:", req.file.path);

            const extraction =
                await extractTextFromUploadedFile(
                    req.file.path,
                    req.file.originalname
                );

            extractedText =
                extraction.text || "";

            extractionMethod =
                extraction.method || "unknown";

            console.log("Extraction Method:", extractionMethod);
            console.log("Characters:", extractedText.length);

        }

        const curriculum =
            await Curriculum.create({

                title,

                grade,

                subject,

                year,

                sourceFileName:
                    req.file?.originalname || null,

                rawText:
                    extractedText,

                status:
                    "uploaded"

            });

        return res.status(201).json({

            success: true,

            message:
                "Curriculum uploaded successfully",

            extractionMethod,

            extractedCharacters:
                extractedText.length,

            curriculum

        });

    } catch (error) {

        console.error("\n========== CURRICULUM UPLOAD ERROR ==========\n");

        console.error(error);

        console.error(error.stack);

        return res.status(500).json({

            success: false,

            message:
                error.message,

            stack:
                process.env.NODE_ENV === "development"
                    ? error.stack
                    : undefined

        });

    }
}

export async function parseCurriculum(req, res) {

    try {

        const { curriculumId } = req.params;

        const curriculum =
            await Curriculum.findById(curriculumId);

        if (!curriculum) {

            return res.status(404).json({

                success: false,

                message:
                    "Curriculum not found"

            });

        }

        const structuredCurriculum =
            await structureCurriculumWithAI(
                curriculum.rawText
            );

        curriculum.structuredCurriculum =
            structuredCurriculum;

        curriculum.status =
            "parsed";

        await curriculum.save();

        return res.json({

            success: true,

            message:
                "Curriculum parsed successfully",

            curriculum

        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({

            success: false,

            message:
                error.message

        });

    }

}

export async function generateScheme(req, res) {

    try {

        const { curriculumId } = req.params;

        const curriculum =
            await Curriculum.findById(curriculumId);

        if (!curriculum) {

            return res.status(404).json({

                success: false,

                message:
                    "Curriculum not found"

            });

        }

        if (
            !curriculum.structuredCurriculum?.strands?.length
        ) {

            return res.status(400).json({

                success: false,

                message:
                    "Curriculum must be parsed before generating scheme."

            });

        }

        const schemeData =
            generateSchemeOfWork(curriculum);

        const scheme =
            await SchemeOfWork.create({

                curriculumId:
                    curriculum._id,

                ...schemeData

            });

        curriculum.status =
            "scheme_generated";

        await curriculum.save();

        return res.status(201).json({

            success: true,

            scheme

        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({

            success: false,

            message:
                error.message

        });

    }

}

export async function getCurricula(req, res) {

    try {

        const curricula =
            await Curriculum.find()
                .sort({ createdAt: -1 });

        return res.json({

            success: true,

            count:
                curricula.length,

            curricula

        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({

            success: false,

            message:
                error.message

        });

    }

}

export async function getSchemes(req, res) {

    try {

        const schemes =
            await SchemeOfWork.find()
                .populate("curriculumId")
                .sort({ createdAt: -1 });

        return res.json({

            success: true,

            count:
                schemes.length,

            schemes

        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({

            success: false,

            message:
                error.message

        });

    }

}

export async function deleteCurriculum(req, res) {

    try {

        await Curriculum.findByIdAndDelete(
            req.params.curriculumId
        );

        return res.json({

            success: true,

            message:
                "Curriculum deleted successfully"

        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({

            success: false,

            message:
                error.message

        });

    }

}

export async function deleteScheme(req, res) {

    try {

        await SchemeOfWork.findByIdAndDelete(
            req.params.schemeId
        );

        return res.json({

            success: true,

            message:
                "Scheme deleted successfully"

        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({

            success: false,

            message:
                error.message

        });

    }

}

export async function getSchemeById(req, res) {

    try {

        const scheme =
            await SchemeOfWork.findById(
                req.params.schemeId
            );

        if (!scheme) {

            return res.status(404).json({

                success: false,

                message:
                    "Scheme not found"

            });

        }

        return res.json({

            success: true,

            scheme

        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({

            success: false,

            message:
                error.message

        });

    }

}