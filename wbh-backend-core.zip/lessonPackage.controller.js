import LessonPlan from "../models/lessonPlan.model.js";
import LessonPackage from "../models/lessonPackage.model.js";
import { generateLessonPackageFromPlan } from "../services/lessonPackageGenerator.service.js";

export async function generateLessonPackage(req, res) {
  try {
    const { lessonPlanId } = req.params;

    const lessonPlan = await LessonPlan.findById(lessonPlanId);

    if (!lessonPlan) {
      return res.status(404).json({
        success: false,
        message: "Lesson plan not found"
      });
    }

    const packageData = await generateLessonPackageFromPlan(lessonPlan);

    const lessonPackage = await LessonPackage.create({
      lessonPlanId: lessonPlan._id,
      schemeId: lessonPlan.schemeId,
      curriculumId: lessonPlan.curriculumId,
      ...packageData
    });

    res.status(201).json({
      success: true,
      message: "Lesson package generated successfully",
      lessonPackage
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to generate lesson package",
      error: error.message
    });
  }
}

export async function getLessonPackages(req, res) {
  try {
    const lessonPackages = await LessonPackage.find()
      .populate("lessonPlanId")
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      count: lessonPackages.length,
      lessonPackages
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch lesson packages",
      error: error.message
    });
  }
}

export async function deleteLessonPackage(req, res) {
  try {
    const { lessonPackageId } = req.params;

    await LessonPackage.findByIdAndDelete(lessonPackageId);

    res.json({
      success: true,
      message: "Lesson package deleted successfully"
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to delete lesson package",
      error: error.message
    });
  }
}