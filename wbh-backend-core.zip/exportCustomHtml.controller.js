import htmlDocx from "html-docx-js";

export const exportCustomHtmlDocx = async (req, res) => {
  try {
    const { html, fileName } = req.body;

    if (!html) {
      return res.status(400).json({
        success: false,
        message: "HTML content is required."
      });
    }

    const docxBuffer =
      htmlDocx.asBlob(html);

    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    );

    res.setHeader(
      "Content-Disposition",
      `attachment; filename=${
        (fileName || "document")
          .replace(/[^a-z0-9]/gi, "_")
          .toLowerCase()
      }.docx`
    );

    return res.send(docxBuffer);

  } catch (error) {

    console.error(
      "DOCX EXPORT ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Failed to export DOCX."
    });
  }
};