import LessonPackage from "../models/lessonPackage.model.js";
import LessonPlan from "../models/lessonPlan.model.js";
import SchemeOfWork from "../models/schemeOfWork.model.js";
import RecordOfWork from "../models/recordOfWork.model.js";

import {
  exportLessonPackageToWord,
  exportLessonPackageToPdf,
  exportLessonPlanToWord,
  exportLessonPlanToPdf,
  exportSchemeToWord,
  exportSchemeToPdf,
  exportRecordOfWorkToWord,
  exportRecordOfWorkToPdf
} from "../services/exportGenerator.service.js";

export async function exportLessonPackageDocx(req, res) {
  try {
    const lessonPackage = await LessonPackage.findById(req.params.lessonPackageId);
    if (!lessonPackage) return res.status(404).json({ success: false, message: "Lesson package not found" });

    const exported = await exportLessonPackageToWord(lessonPackage);
    res.download(exported.filePath, exported.filename);
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to export lesson package as Word", error: error.message });
  }
}

export async function exportLessonPackagePdf(req, res) {
  try {
    const lessonPackage = await LessonPackage.findById(req.params.lessonPackageId);
    if (!lessonPackage) return res.status(404).json({ success: false, message: "Lesson package not found" });

    const exported = await exportLessonPackageToPdf(lessonPackage);
    res.download(exported.filePath, exported.filename);
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to export lesson package as PDF", error: error.message });
  }
}

export async function exportLessonPlanDocx(req, res) {
  try {
    const lessonPlan = await LessonPlan.findById(req.params.lessonPlanId);
    if (!lessonPlan) return res.status(404).json({ success: false, message: "Lesson plan not found" });

    const exported = await exportLessonPlanToWord(lessonPlan);
    res.download(exported.filePath, exported.filename);
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to export lesson plan as Word", error: error.message });
  }
}

export async function exportLessonPlanPdf(req, res) {
  try {
    const lessonPlan = await LessonPlan.findById(req.params.lessonPlanId);
    if (!lessonPlan) return res.status(404).json({ success: false, message: "Lesson plan not found" });

    const exported = await exportLessonPlanToPdf(lessonPlan);
    res.download(exported.filePath, exported.filename);
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to export lesson plan as PDF", error: error.message });
  }
}

export async function exportSchemeDocx(req, res) {
  try {
    const scheme = await SchemeOfWork.findById(req.params.schemeId);
    if (!scheme) return res.status(404).json({ success: false, message: "Scheme not found" });

    const exported = await exportSchemeToWord(scheme);
    res.download(exported.filePath, exported.filename);
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to export scheme as Word", error: error.message });
  }
}

export async function exportSchemePdf(req, res) {
  try {
    const scheme = await SchemeOfWork.findById(req.params.schemeId);
    if (!scheme) return res.status(404).json({ success: false, message: "Scheme not found" });

    const exported = await exportSchemeToPdf(scheme);
    res.download(exported.filePath, exported.filename);
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to export scheme as PDF", error: error.message });
  }
}

export async function exportRecordOfWorkDocx(req, res) {
  try {
    const record = await RecordOfWork.findById(req.params.recordId);

    if (!record) {
      return res.status(404).json({
        success: false,
        message: "Record of work not found"
      });
    }

    const exported = await exportRecordOfWorkToWord(record);
    res.download(exported.filePath, exported.filename);
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to export record of work as Word",
      error: error.message
    });
  }
}

export async function exportRecordOfWorkPdf(req, res) {
  try {
    const record = await RecordOfWork.findById(req.params.recordId);

    if (!record) {
      return res.status(404).json({
        success: false,
        message: "Record of work not found"
      });
    }

    const exported = await exportRecordOfWorkToPdf(record);
    res.download(exported.filePath, exported.filename);
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to export record of work as PDF",
      error: error.message
    });
  }
}