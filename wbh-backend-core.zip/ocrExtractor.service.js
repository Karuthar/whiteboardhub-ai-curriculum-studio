import fs from "fs";
import path from "path";
import { createRequire } from "module";
import { createWorker } from "tesseract.js";
import pdf from "pdf-poppler";

const require = createRequire(import.meta.url);
const pdfParse = require("pdf-parse");

export async function extractTextFromUploadedFile(filePath, originalName = "") {
  const extension = path.extname(originalName).toLowerCase();

  if (extension === ".pdf") {
    return await extractTextFromPdf(filePath);
  }

  if ([".png", ".jpg", ".jpeg"].includes(extension)) {
    return await extractTextFromImage(filePath);
  }

  throw new Error("Unsupported file type. Please upload PDF, PNG, JPG, or JPEG.");
}

async function extractTextFromPdf(filePath) {
  const buffer = fs.readFileSync(filePath);

  try {
    const parsed = await pdfParse(buffer);

    if (parsed.text && parsed.text.trim().length > 100) {
      return {
        method: "pdf-text",
        text: parsed.text.trim()
      };
    }
  } catch (error) {
    console.log("PDF text extraction failed. Trying OCR fallback...");
  }

  return await extractTextFromScannedPdf(filePath);
}

async function extractTextFromScannedPdf(filePath) {
  const outputDir = path.join(process.cwd(), "uploads", "ocr-pages");

  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  const filePrefix = `page-${Date.now()}`;

  const options = {
    format: "png",
    out_dir: outputDir,
    out_prefix: filePrefix
  };

  await pdf.convert(filePath, options);

  const pageImages = fs
    .readdirSync(outputDir)
    .filter((file) => file.startsWith(filePrefix) && file.endsWith(".png"))
    .map((file) => path.join(outputDir, file))
    .sort();

  if (!pageImages.length) {
    throw new Error("Could not convert scanned PDF pages to images for OCR.");
  }

  const worker = await createWorker("eng");

  let fullText = "";

  for (const imagePath of pageImages) {
    const result = await worker.recognize(imagePath);
    fullText += "\n\n" + result.data.text;
  }

  await worker.terminate();

  return {
    method: "ocr-pdf",
    text: fullText.trim()
  };
}

async function extractTextFromImage(filePath) {
  const worker = await createWorker("eng");
  const result = await worker.recognize(filePath);
  await worker.terminate();

  return {
    method: "ocr-image",
    text: result.data.text.trim()
  };
}