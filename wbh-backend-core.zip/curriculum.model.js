import mongoose from "mongoose";

const curriculumSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true
    },

    country: {
      type: String,
      default: "Kenya"
    },

    curriculumBody: {
      type: String,
      default: "KICD"
    },

    educationSystem: {
      type: String,
      default: ""
    },

    grade: {
      type: String,
      required: true
    },

    subject: {
      type: String,
      required: true
    },

    year: Number,

    sourceFileName: String,

    rawText: String,

    parserVersion: {
      type: String,
      default: "2.0"
    },

    documentType: {
      type: String,
      default: ""
    },

    structuredCurriculum: {
      strands: [
        {
          strandNumber: String,

          strandTitle: String,

          subStrands: [
            {
              subStrandNumber: String,

              subStrandTitle: String,

              specificLearningOutcomes: [String],

              suggestedLearningExperiences: [String],

              keyInquiryQuestions: [String],

              coreCompetencies: [String],

              values: [String],

              pcis: [String],

              suggestedAssessment: [String]
            }
          ]
        }
      ]
    },

    validation: {
      missingFields: {
        type: [String],
        default: []
      },

      warnings: {
        type: [String],
        default: []
      },

      confidence: {
        type: Number,
        default: 0
      }
    },

    status: {
      type: String,
      enum: [
        "uploaded",
        "parsed",
        "validated",
        "scheme_generated"
      ],
      default: "uploaded"
    }
  },
  {
    timestamps: true
  }
);

export default mongoose.model(
  "Curriculum",
  curriculumSchema
);