import express from "express";
import {
  generateLessonPlan,
  getLessonPlans
} from "../controllers/lessonPlan.controller.js";

const router = express.Router();

router.post("/:schemeId/generate", generateLessonPlan);
router.get("/", getLessonPlans);

export default router;
