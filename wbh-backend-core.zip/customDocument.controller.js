import CustomDocument from "../models/customDocument.model.js";
import { exportCustomDocumentToDocx } from "../services/customDocumentExport.service.js";

export async function createCustomDocument(req, res) {
  try {
    console.log("CUSTOM DOC TYPE:");
console.log(req.body.sourceDocumentType);

console.log("CUSTOM DOC TITLE:");
console.log(req.body.title);
    const doc = await CustomDocument.create(req.body);

    res.status(201).json({
      success: true,
      customDocument: doc
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to create custom document",
      error: error.message
    });
  }
}

export async function getCustomDocuments(req, res) {
  try {
    const documents = await CustomDocument.find()
      .sort({ updatedAt: -1 })
      .limit(100);

    res.json({
      success: true,
      count: documents.length,
      documents
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch custom documents",
      error: error.message
    });
  }
}

export async function getCustomDocumentById(req, res) {
  try {
    const document = await CustomDocument.findById(req.params.id);

    if (!document) {
      return res.status(404).json({
        success: false,
        message: "Custom document not found"
      });
    }

    res.json({
      success: true,
      document
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch custom document",
      error: error.message
    });
  }
}

export async function updateCustomDocument(req, res) {
  try {
    const document = await CustomDocument.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true
      }
    );

    if (!document) {
      return res.status(404).json({
        success: false,
        message: "Custom document not found"
      });
    }

    res.json({
      success: true,
      document
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to update custom document",
      error: error.message
    });
  }
}

export async function deleteCustomDocument(req, res) {
  try {
    const document = await CustomDocument.findByIdAndDelete(
      req.params.id
    );

    if (!document) {
      return res.status(404).json({
        success: false,
        message: "Custom document not found"
      });
    }

    res.json({
      success: true,
      message: "Custom document deleted"
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to delete custom document",
      error: error.message
    });
  }
}

export async function exportCustomDocumentDocx(req, res) {
  try {
    const document = await CustomDocument.findById(req.params.id);

    if (!document) {
      return res.status(404).json({
        success: false,
        message: "Custom document not found"
      });
    }

    console.log("EXPORT START");

const result =
  await exportCustomDocumentToDocx(document);

console.log("EXPORT RESULT:");
console.log(result);

const { filename, filePath } = result;
    console.log("DOWNLOADING:");
console.log(filePath);

return res.download(filePath, filename);
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to export custom document",
      error: error.message
    });
  }
}