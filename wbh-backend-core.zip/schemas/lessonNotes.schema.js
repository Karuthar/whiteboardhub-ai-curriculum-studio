export const LessonNotesSchema = {

    metadata: {},

    notes: {}

};