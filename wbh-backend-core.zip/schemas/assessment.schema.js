export const AssessmentSchema = {

    metadata: {},

    questions: []

};