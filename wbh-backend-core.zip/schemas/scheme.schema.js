export const SchemeSchema = {

    metadata: {},

    terms: []

};