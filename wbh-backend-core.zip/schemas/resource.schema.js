export const ResourceSchema = {

    metadata: {},

    resources: []

};s