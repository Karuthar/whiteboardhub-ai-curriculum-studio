export const CurriculumSchema = {

    metadata: {

        title: "",

        educationSystem: "",

        country: "",

        curriculumBody: "",

        subject: "",

        grade: "",

        year: "",

        parserVersion: ""

    },

    strands: [

        {

            id: "",

            title: "",

            description: "",

            subStrands: [

                {

                    id: "",

                    title: "",

                    learningOutcomes: [],

                    learningExperiences: [],

                    keyInquiryQuestions: [],

                    coreCompetencies: [],

                    values: [],

                    pcis: [],

                    assessment: [],

                    resources: []

                }

            ]

        }

    ]

};