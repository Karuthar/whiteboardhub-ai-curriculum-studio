export const LessonPlanSchema = {

    metadata: {},

    lesson: {}

};