export const RecordSchema = {

    metadata: {},

    records: []

};