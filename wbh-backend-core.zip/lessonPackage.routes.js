import express from "express";
import {
  generateLessonPackage,
  getLessonPackages
} from "../controllers/lessonPackage.controller.js";

const router = express.Router();

router.post("/:lessonPlanId/generate", generateLessonPackage);
router.get("/", getLessonPackages);

export default router;
