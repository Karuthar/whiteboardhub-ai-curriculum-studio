import OpenAI from "openai";

export async function generateLessonPackageFromPlan(lessonPlan) {
  if (!process.env.OPENAI_API_KEY) {
    return fallbackLessonPackage(lessonPlan);
  }

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    const response = await client.responses.create({
      model: process.env.AI_MODEL || "gpt-5.4",
      input: `
Generate a complete CBC/KICD Biology lesson package as valid JSON only.

Use this JSON shape:
{
  "teacherNotes": "string",
  "teacherNotesSections": {
    "topic": "string",
    "subTopic": "string",
    "keyConcepts": ["string"],
    "detailedTeacherExposition": "string",
    "commonMisconceptions": ["string"],
    "teachingHints": ["string"],
    "boardSummary": ["string"],
    "learnerSupportAndRemediation": ["string"],
    "extensionAndEnrichment": ["string"]
  },
  "learnerNotes": "string",
  "learnerNotesSections": {
    "topic": "string",
    "keyTerms": ["string"],
    "simpleExplanation": "string",
    "examples": ["string"],
    "diagramPrompts": ["string"],
    "quickCheckQuestions": ["string"],
    "summary": ["string"],
    "assignment": "string"
  },
  "learningExperiences": ["string"],
  "assessmentItems": [
    {
      "type": "string",
      "question": "string",
      "expectedAnswer": "string",
      "marks": 1
    }
  ],
  "rubric": [
    {
      "level": "EE2/EE1/ME2/ME1/AE2/AE1/BE2/BE1",
      "descriptor": "string"
    }
  ],
  "homework": "string",
  "resources": ["string"]
}

Use CBC inquiry-based learning and learner-centred pedagogy.
Assessment must include oral, written, application, practical/task-based, and observation-checklist items.
Use the official 8-level CBC rubric: EE2, EE1, ME2, ME1, AE2, AE1, BE2, BE1.

Lesson plan:
${JSON.stringify(lessonPlan, null, 2)}
`
    });

    return {
      ...JSON.parse(response.output_text),
      generatedBy: "ai"
    };
  } catch (error) {
    console.log("AI lesson package generation failed. Using fallback.");
    console.log(error.message);
    return fallbackLessonPackage(lessonPlan);
  }
}

function fallbackLessonPackage(lessonPlan) {
  const topic = lessonPlan.lessonTitle || "Biology Lesson";
  const subTopic = lessonPlan.subStrand || topic;
  const strand = lessonPlan.strand || "Biology";

  const outcomes = lessonPlan.learningOutcomes || [];
  const resources = lessonPlan.learningResources || [
    "Curriculum design",
    "Charts",
    "Digital device",
    "Locally available materials"
  ];

  const keyConcepts = buildKeyConcepts(lessonPlan);

  return {
    teacherNotes: `
Topic: ${topic}

Sub-topic: ${subTopic}

Key Concepts:
${keyConcepts.map((item) => `- ${item}`).join("\n")}

Detailed Teacher Exposition:
This lesson focuses on ${subTopic} under the strand ${strand}. The teacher should guide learners to connect prior knowledge with the new concept through inquiry, observation, discussion, explanation, and application.

Common Misconceptions:
- Learners may confuse related biological terms.
- Learners may memorise facts without understanding their functional meaning.
- Learners may fail to connect the concept to real-life biological situations.

Teaching Hints:
- Begin with questions that activate prior knowledge.
- Use diagrams, charts, models, specimens, or digital media where available.
- Encourage group discussion and learner explanation.
- Clarify difficult vocabulary before learners attempt assessment tasks.
- Link the concept to familiar local or real-life examples.

Board Summary:
${buildBoardSummary(topic, subTopic, outcomes).map((item) => `- ${item}`).join("\n")}
`.trim(),

    teacherNotesSections: {
      topic,
      subTopic,
      keyConcepts,
      detailedTeacherExposition:
        `This lesson focuses on ${subTopic} under ${strand}. The teacher should guide learners through an inquiry-based process where they recall prior knowledge, explore examples or resources, explain observations, elaborate through application, and evaluate understanding through questioning or task performance.`,
      commonMisconceptions: [
        "Learners may confuse related biological terms.",
        "Learners may memorise facts without understanding their functional meaning.",
        "Learners may fail to connect the concept to real-life biological situations."
      ],
      teachingHints: [
        "Begin with questions that activate prior knowledge.",
        "Use diagrams, charts, models, specimens, or digital media where available.",
        "Encourage group discussion and learner explanation.",
        "Clarify difficult vocabulary before assessment tasks.",
        "Link the concept to familiar local or real-life examples."
      ],
      boardSummary: buildBoardSummary(topic, subTopic, outcomes),
      learnerSupportAndRemediation: [
        "Pair learners who need support with more confident peers.",
        "Re-teach difficult vocabulary using diagrams or examples.",
        "Provide short guided questions for learners requiring reinforcement.",
        "Use oral questioning to check understanding before written tasks."
      ],
      extensionAndEnrichment: [
        "Ask advanced learners to research an additional application of the concept.",
        "Let learners prepare a short presentation, model, diagram, or comparison table.",
        "Encourage learners to connect the lesson to environmental, health, or technological contexts."
      ]
    },

    learnerNotes: `
Topic: ${subTopic}

Key Terms:
${keyConcepts.map((item) => `- ${item}`).join("\n")}

Simple Explanation:
This lesson helps learners understand ${subTopic}. Learners explore the concept through observation, discussion, explanation, and application to real-life biological situations.

Examples:
- Biological structures or situations related to the lesson
- Everyday applications connected to the concept
- Teacher demonstrations or learner observations

Quick Check Questions:
- What is the meaning of ${subTopic}?
- Why is the concept important in biology?
- How does the concept apply in real life?

Summary:
- ${subTopic} is an important biological concept.
- Learners should explain the concept clearly.
- Learners should connect the concept to real-life situations.

Assignment:
Write a short summary of the lesson and answer two questions related to the concept.
`.trim(),

    learnerNotesSections: {
      topic: subTopic,
      keyTerms: keyConcepts,
      simpleExplanation:
        `This lesson helps learners understand ${subTopic}. Learners explore the concept through observation, discussion, explanation, and application.`,
      examples: [
        "Examples drawn from biological situations",
        "Teacher demonstrations",
        "Real-life applications related to the lesson"
      ],
      diagramPrompts: [
        `Draw and label a diagram related to ${subTopic}.`,
        "Sketch and explain the main concept learned in class."
      ],
      quickCheckQuestions: [
        `What is ${subTopic}?`,
        `Why is ${subTopic} important?`,
        "Explain one real-life application of the concept."
      ],
      summary: [
        `${subTopic} is an important biological concept.`,
        "The lesson should be explained using examples and observations.",
        "Learners should connect the lesson to real-life situations."
      ],
      assignment:
        `Write a short summary of ${subTopic} and answer two questions related to the lesson.`
    },

    learningExperiences: buildLearningExperiences(lessonPlan),

    assessmentItems: [
      {
        type: "Oral Question",
        question: `What is the main idea in ${subTopic}?`,
        expectedAnswer:
          "Learner explains the main concept correctly using relevant biological language.",
        marks: 2
      },
      {
        type: "Written Question",
        question: `Explain two important points about ${subTopic}.`,
        expectedAnswer:
          "Learner gives two correct points related to the lesson concept.",
        marks: 4
      },
      {
        type: "Application Question",
        question: `Describe one real-life application of ${subTopic}.`,
        expectedAnswer:
          "Learner links the concept to a correct real-life biological situation.",
        marks: 3
      },
      {
        type: "Practical / Task-Based Assessment",
        question:
          `Carry out or describe a simple task, observation, model, diagram, or group activity related to ${subTopic}.`,
        expectedAnswer:
          "Learner completes the task accurately and explains the observation or outcome.",
        marks: 5
      },
      {
        type: "Observation Checklist",
        question:
          "Teacher observes learner participation, collaboration, accuracy of responses, and ability to explain findings.",
        expectedAnswer:
          "Learner participates actively, collaborates appropriately, and communicates biological ideas clearly.",
        marks: 4
      }
    ],

    rubric: buildEightLevelRubric(subTopic),

    homework:
      `Write a short summary of ${subTopic} and answer two questions based on the key learning outcomes.`,

    resources,

    generatedBy: "fallback"
  };
}

function buildKeyConcepts(lessonPlan) {
  const concepts = [];

  if (lessonPlan.strand) concepts.push(lessonPlan.strand);
  if (lessonPlan.subStrand) concepts.push(lessonPlan.subStrand);

  (lessonPlan.learningOutcomes || []).forEach((outcome) => {
    concepts.push(outcome);
  });

  return concepts.slice(0, 6);
}

function buildBoardSummary(topic, subTopic, outcomes) {
  const summary = [
    `Lesson topic: ${topic}`,
    `Main focus: ${subTopic}`
  ];

  outcomes.slice(0, 4).forEach((outcome) => {
    summary.push(outcome);
  });

  summary.push(
    "Key idea: Learners should explain the concept and apply it to real-life biological situations."
  );

  return summary;
}

function buildLearningExperiences(lessonPlan) {
  const experiences = [];

  experiences.push(
    "Learners respond to guiding questions to activate prior knowledge."
  );

  if (lessonPlan.introduction) {
    experiences.push(lessonPlan.introduction);
  }

  (lessonPlan.lessonDevelopment || []).forEach((phase) => {
    if (phase.learnerActivity) experiences.push(phase.learnerActivity);
  });

  experiences.push("Learners discuss findings and present responses to the class.");
  experiences.push("Learners complete a short assessment task based on the learning outcomes.");

  return experiences;
}

function buildEightLevelRubric(subTopic) {
  return [
    {
      level: "EE2",
      descriptor:
        `Learner demonstrates exceptional mastery of ${subTopic}, explains ideas clearly, applies them accurately, and supports others.`
    },
    {
      level: "EE1",
      descriptor:
        `Learner demonstrates strong mastery of ${subTopic} with clear explanations and accurate application.`
    },
    {
      level: "ME2",
      descriptor:
        `Learner is fully competent and explains ${subTopic} correctly with minimal support.`
    },
    {
      level: "ME1",
      descriptor:
        `Learner meets expectation by showing correct understanding of the main ideas in ${subTopic}.`
    },
    {
      level: "AE2",
      descriptor:
        `Learner shows partial competency and can explain some ideas in ${subTopic} with guidance.`
    },
    {
      level: "AE1",
      descriptor:
        `Learner shows emerging understanding of ${subTopic} but requires regular support.`
    },
    {
      level: "BE2",
      descriptor:
        `Learner demonstrates minimal competency and requires close support to understand ${subTopic}.`
    },
    {
      level: "BE1",
      descriptor:
        `Learner has significant difficulty with ${subTopic} and requires intensive remediation.`
    }
  ];
}