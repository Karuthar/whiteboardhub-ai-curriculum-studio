import mongoose from "mongoose";

const recordOfWorkSchema = new mongoose.Schema(
  {
    schemeId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "SchemeOfWork"
    },

    lessonPlanId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "LessonPlan"
    },

    curriculumId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Curriculum"
    },

    subject: {
      type: String,
      required: true
    },

    grade: {
      type: String,
      required: true
    },

    termNumber: {
      type: Number,
      required: true
    },

    weekNumber: {
      type: Number,
      required: true
    },

    lessonNumber: {
      type: mongoose.Schema.Types.Mixed,
      required: true
    },

    date: {
      type: String,
      default: ""
    },

    period: {
      type: String,
      default: ""
    },

    strand: {
      type: String,
      default: ""
    },

    subStrand: {
      type: String,
      default: ""
    },

    workCovered: {
      type: String,
      default: ""
    },

    reference: {
      type: String,
      default: "KICD Curriculum Design, Approved Biology Textbook, Teacher Notes"
    },

    remarks: {
      type: String,
      default: ""
    },

    generatedBy: {
      type: String,
      enum: ["system", "teacher", "ai", "fallback"],
      default: "system"
    }
  },
  { timestamps: true }
);

export default mongoose.model("RecordOfWork", recordOfWorkSchema);