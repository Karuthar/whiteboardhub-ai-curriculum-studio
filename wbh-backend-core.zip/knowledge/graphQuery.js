export function findNode(

    graph,

    id

){

    return graph.getNode(id);

}

export function relatedNodes(

    graph,

    id

){

    return graph.getEdges(id);

}