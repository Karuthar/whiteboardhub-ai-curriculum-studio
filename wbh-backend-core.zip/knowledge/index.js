import {

buildKnowledgeGraph

}

from "./graphBuilder.js";

import {

validateGraph

}

from "./graphValidator.js";

export function createKnowledgeGraph(curriculum){

    const graph =

        buildKnowledgeGraph(

            curriculum

        );

    const validation =

        validateGraph(

            graph

        );

    return{

        graph,

        validation

    };

}