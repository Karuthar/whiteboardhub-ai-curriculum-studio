export function validateGraph(graph){

    return{

        nodeCount:

            graph.nodes.size,

        edgeCount:

            graph.edges.length

    };

}