export default class CurriculumGraph {

    constructor() {

        this.nodes = new Map();

        this.edges = [];

    }

    addNode(id, type, data = {}) {

        this.nodes.set(id, {

            id,

            type,

            data

        });

    }

    addEdge(from, to, relation) {

        this.edges.push({

            from,

            to,

            relation

        });

    }

    getNode(id) {

        return this.nodes.get(id);

    }

    getEdges(id) {

        return this.edges.filter(

            edge =>

                edge.from === id ||

                edge.to === id

        );

    }

}