import CurriculumGraph
from "./curriculumGraph.js";

export function buildKnowledgeGraph(curriculum) {

    const graph =
        new CurriculumGraph();

    curriculum.strands.forEach(strand => {

        graph.addNode(

            strand.id,

            "strand",

            strand

        );

        strand.subStrands.forEach(sub => {

            graph.addNode(

                sub.id,

                "subStrand",

                sub

            );

            graph.addEdge(

                strand.id,

                sub.id,

                "contains"

            );

            sub.learningOutcomes.forEach(

                (outcome,index)=>{

                    const id =

                        `${sub.id}-O${index+1}`;

                    graph.addNode(

                        id,

                        "learningOutcome",

                        {

                            text: outcome

                        }

                    );

                    graph.addEdge(

                        sub.id,

                        id,

                        "achieves"

                    );

                }

            );

        });

    });

    return graph;

}