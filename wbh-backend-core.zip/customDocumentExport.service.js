import {
    generateDocument
} from "./documentEngine/engine/documentEngine.js";

export async function exportCustomDocumentToDocx(document) {

    return generateDocument(document);

}