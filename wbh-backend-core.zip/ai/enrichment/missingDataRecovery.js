export function recoverMissingData(curriculum){

    if(

        !curriculum.metadata.country

    ){

        curriculum.metadata.country="Kenya";

    }

    return curriculum;

}