import {

checkCompleteness

}

from "./completenessChecker.js";

import {

recoverMissingData

}

from "./missingDataRecovery.js";

import {

expandSemantics

}

from "./semanticExpander.js";

import {

checkConsistency

}

from "./consistencyChecker.js";

import {

calculateConfidence

}

from "./confidenceEngine.js";

import {

createValidationReport

}

from "./validationReporter.js";

export function enrichCurriculum(

    curriculum,

    validation

){

    const completeness=

        checkCompleteness(curriculum);

    curriculum=

        recoverMissingData(curriculum);

    curriculum=

        expandSemantics(curriculum);

    const consistency=

        checkConsistency(curriculum);

    const confidence=

        calculateConfidence(

            completeness,

            validation

        );

    const report=

        createValidationReport(

            validation,

            confidence

        );

    return{

        curriculum,

        completeness,

        consistency,

        confidence,

        report

    };

}