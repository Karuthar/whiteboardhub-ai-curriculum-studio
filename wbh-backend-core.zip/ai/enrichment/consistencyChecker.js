export function checkConsistency(curriculum){

    return{

        warnings:[],

        passed:true

    };

}