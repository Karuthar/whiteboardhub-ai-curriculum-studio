export function expandSemantics(curriculum){

    return curriculum;

}