export function checkCompleteness(curriculum){

    const report = {

        missingFields: [],

        complete: true

    };

    if(!curriculum.metadata.title){

        report.complete = false;

        report.missingFields.push("title");

    }

    if(!curriculum.metadata.subject){

        report.complete = false;

        report.missingFields.push("subject");

    }

    if(!curriculum.metadata.grade){

        report.complete = false;

        report.missingFields.push("grade");

    }

    if(curriculum.strands.length===0){

        report.complete=false;

        report.missingFields.push("strands");

    }

    return report;

}