export function calculateConfidence(

    completeness,

    validation

){

    let score = 100;

    score -=

        completeness.missingFields.length * 10;

    score -=

        validation.warnings.length * 5;

    if(score<0)

        score=0;

    return score;

}