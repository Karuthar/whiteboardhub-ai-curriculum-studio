export function createValidationReport(

    validation,

    confidence

){

    return{

        validation,

        confidence,

        generatedAt:

            new Date()

    };

}