export function buildCrossReferences(

    graph

){

    return graph;

}