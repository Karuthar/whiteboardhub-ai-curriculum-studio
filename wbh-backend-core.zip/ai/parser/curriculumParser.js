export async function parseCurriculum(
    cleanedText,
    classification
) {

    return {

        rawText: cleanedText,

        classification,

        structuredCurriculum: {}

    };

}