import BaseParser
from "./baseParser.js";

export default class CambridgeParser
extends BaseParser{

    parse(text){

        return{

            educationSystem:"Cambridge",

            raw:text

        };

    }

}