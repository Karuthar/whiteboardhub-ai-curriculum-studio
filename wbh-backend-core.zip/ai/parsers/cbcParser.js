import BaseParser
from "./baseParser.js";

export default class CBCParser
extends BaseParser {

    parse(text){

        return{

            educationSystem:"CBC",

            raw:text

        };

    }

}