import BaseParser
from "./baseParser.js";

export default class EightFourFourParser
extends BaseParser{

    parse(text){

        return{

            educationSystem:"8-4-4",

            raw:text

        };

    }

}