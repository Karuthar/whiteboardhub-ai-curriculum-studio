import BaseParser
from "./baseParser.js";

export default class IBParser
extends BaseParser{

    parse(text){

        return{

            educationSystem:"IB",

            raw:text

        };

    }

}