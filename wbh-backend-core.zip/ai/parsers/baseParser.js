export default class BaseParser {

    parse(text) {

        throw new Error(
            "Parser not implemented."
        );

    }

}