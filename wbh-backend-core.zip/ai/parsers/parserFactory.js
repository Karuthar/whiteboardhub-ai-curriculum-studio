import CBCParser
from "./cbcParser.js";

import EightFourFourParser
from "./eightFourFourParser.js";

import CambridgeParser
from "./cambridgeParser.js";

import IBParser
from "./ibParser.js";

export function createParser(system){

    switch(system){

        case "CBC":

            return new CBCParser();

        case "8-4-4":

            return new EightFourFourParser();

        case "Cambridge":

            return new CambridgeParser();

        case "IB":

            return new IBParser();

        default:

            return new CBCParser();

    }

}