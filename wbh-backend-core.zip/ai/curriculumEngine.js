import {
    extractCurriculum
} from "./intelligence/curriculumExtractor.js";

import {
    interpretCurriculum
} from "./intelligence/curriculumInterpreter.js";

import {
    mapCurriculum
} from "./intelligence/curriculumMapper.js";

import {
    reasonCurriculum
} from "./intelligence/curriculumReasoner.js";

import {
    normalizeCurriculum
} from "./normalizer/curriculumNormalizer.js";

import {
    validateCurriculum
} from "./validator/curriculumValidator.js";

import {
    createKnowledgeGraph
} from "../knowledge/index.js";

import {
    enrichCurriculum
} from "./enrichment/enrichmentEngine.js";

export async function processCurriculum(rawText) {

    const extraction =
        extractCurriculum(rawText);

    let curriculum =
        extraction.curriculum;

    curriculum =
        interpretCurriculum(curriculum);

    curriculum =
        mapCurriculum(curriculum);

    curriculum =
        normalizeCurriculum(curriculum);

    const validation =
        validateCurriculum(curriculum);

    const enrichment =
        enrichCurriculum(
            curriculum,
            validation
        );

    curriculum =
        enrichment.curriculum;

    const reasoning =
        reasonCurriculum(curriculum);

    const knowledge =
        createKnowledgeGraph(curriculum);

    return {

        classification:
            extraction.classification,

        curriculum,

        validation,

        reasoning,

        knowledge,

        enrichment

    };

}