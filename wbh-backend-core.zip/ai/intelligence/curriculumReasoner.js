export function reasonCurriculum(curriculum) {

    return {

        strandCount:

            curriculum.strands.length,

        subStrandCount:

            curriculum.strands.reduce(

                (total,strand)=>

                    total+

                    strand.subStrands.length,

                0

            )

    };

}