import { CurriculumSchema }
from "../../schemas/curriculum.schema.js";

import {
    classifyCurriculum
}
from "./curriculumClassifier.js";

import {
    createParser
}
from "../parsers/parserFactory.js";

import {
    extractMetadata
}
from "../extractors/metadataExtractor.js";

import {
    extractStrands
}
from "../extractors/strandExtractor.js";

export function extractCurriculum(rawText=""){

    const classification =
        classifyCurriculum(rawText);

    const parser =
        createParser(
            classification.educationSystem
        );

    const parserOutput =
        parser.parse(rawText);

    const curriculum =
        structuredClone(
            CurriculumSchema
        );

    curriculum.metadata = {

        ...curriculum.metadata,

        ...extractMetadata(rawText),

        educationSystem:
            classification.educationSystem,

        country:
            classification.country,

        curriculumBody:
            classification.curriculumBody

    };

    curriculum.strands =
        extractStrands(rawText);

    curriculum.parserOutput =
        parserOutput;

    return{

        classification,

        curriculum

    };

}