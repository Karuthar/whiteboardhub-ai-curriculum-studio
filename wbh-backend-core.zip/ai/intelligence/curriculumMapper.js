export function mapCurriculum(curriculum) {

    return curriculum;

}