export function classifyCurriculum(text = "") {

    const lower = text.toLowerCase();

    return {

        educationSystem:

            lower.includes("cbc")
                ? "CBC"
                : lower.includes("844")
                    ? "8-4-4"
                    : "UNKNOWN",

        country:

            lower.includes("kenya")
                ? "Kenya"
                : "Unknown",

        curriculumBody:

            lower.includes("kicd")
                ? "KICD"
                : "Unknown"

    };

}