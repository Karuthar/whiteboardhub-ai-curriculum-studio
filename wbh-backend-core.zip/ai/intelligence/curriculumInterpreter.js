export function interpretCurriculum(curriculum) {

    if (!curriculum)
        return curriculum;

    curriculum.metadata.interpreted = true;

    return curriculum;

}