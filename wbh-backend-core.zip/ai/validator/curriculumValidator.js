export function validateCurriculum(curriculum) {

    return {

        valid: true,

        confidence: 1,

        warnings: [],

        missingFields: []

    };

}