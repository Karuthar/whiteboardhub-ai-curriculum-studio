export function cleanCurriculum(rawText = "") {

    return rawText

        .replace(/\r/g, "")

        .replace(/[ \t]+/g, " ")

        .replace(/\n{3,}/g, "\n\n")

        .trim();

}