export function extractAssessment(text){

    return [];

}