export function extractLearningOutcomes(text){

    const outcomes=[];

    const regex =
        /Learner should be able to[:\s]+([^\n]+)/gi;

    let match;

    while((match=regex.exec(text))!==null){

        outcomes.push(

            match[1].trim()

        );

    }

    return outcomes;

}