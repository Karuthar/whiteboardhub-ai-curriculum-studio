export function extractStrands(text){

    const strands = [];

    const regex =
        /Strand\s+\d+[:\s]+([^\n]+)/gi;

    let match;

    while((match = regex.exec(text)) !== null){

        strands.push({

            id:
                `STR-${strands.length+1}`,

            title:
                match[1].trim(),

            subStrands:[]

        });

    }

    return strands;

}