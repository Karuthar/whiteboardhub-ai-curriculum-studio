export function extractMetadata(text = "") {

    return {

        title:
            findTitle(text),

        subject:
            findSubject(text),

        grade:
            findGrade(text),

        year:
            findYear(text)

    };

}

function findTitle(text){

    const first =
        text.split("\n")[0];

    return first.trim();

}

function findSubject(text){

    const match =
        text.match(
            /(Biology|Physics|Chemistry|Mathematics|English|Kiswahili)/i
        );

    return match ? match[1] : "";

}

function findGrade(text){

    const match =
        text.match(
            /(Grade|Form)\s*\d+/i
        );

    return match ? match[0] : "";

}

function findYear(text){

    const match =
        text.match(/20\d\d/);

    return match ? match[0] : "";

}