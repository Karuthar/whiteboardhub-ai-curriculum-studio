export function extractSubStrands(text){

    const items=[];

    const regex =
        /Sub[- ]?Strand[:\s]+([^\n]+)/gi;

    let match;

    while((match=regex.exec(text))!==null){

        items.push({

            id:
                `SUB-${items.length+1}`,

            title:
                match[1].trim(),

            learningOutcomes:[],

            learningExperiences:[],

            assessment:[]

        });

    }

    return items;

}