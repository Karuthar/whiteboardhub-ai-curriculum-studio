export function extractLearningExperiences(text){

    return [];

}