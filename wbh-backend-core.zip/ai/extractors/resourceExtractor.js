export function extractResources(text){

    return [];

}