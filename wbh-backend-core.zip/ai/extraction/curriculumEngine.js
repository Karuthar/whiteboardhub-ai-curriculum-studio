import { extractText } from "../../extraction/textExtractor.js";

import { cleanCurriculum } from "../cleaner/curriculumCleaner.js";

import { classifyCurriculum } from "../classifier/curriculumClassifier.js";

import { parseCurriculum } from "../parser/curriculumParser.js";

import { validateCurriculum } from "../validator/curriculumValidator.js";

import { normalizeCurriculum } from "../normalizer/curriculumNormalizer.js";

export async function processCurriculum(file) {

    const rawText =
        await extractText(file);

    const cleaned =
        cleanCurriculum(rawText);

    const classification =
        await classifyCurriculum(cleaned);

    const parsed =
        await parseCurriculum(
            cleaned,
            classification
        );

    const validation =
        validateCurriculum(parsed);

    const normalized =
        normalizeCurriculum(parsed);

    return {

        classification,

        curriculum: normalized,

        validation

    };

}