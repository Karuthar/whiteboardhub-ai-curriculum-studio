export function normalizeCurriculum(curriculum) {

    return curriculum;

}