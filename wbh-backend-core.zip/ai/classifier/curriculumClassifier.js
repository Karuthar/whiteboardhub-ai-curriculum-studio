export async function classifyCurriculum(text) {

    return {

        country: "Kenya",

        curriculumBody: "KICD",

        educationSystem: "CBC",

        confidence: 1.0

    };

}