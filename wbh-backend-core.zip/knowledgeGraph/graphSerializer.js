export function serializeGraph(graph) {

    return graph;

}