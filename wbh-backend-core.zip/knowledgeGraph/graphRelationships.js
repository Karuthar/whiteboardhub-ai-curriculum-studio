export function createRelationships(graph) {

    return graph;

}