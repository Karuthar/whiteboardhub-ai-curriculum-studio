export function nextNode(graph, nodeId) {

    return null;

}