export function buildKnowledgeGraph(curriculum) {

    return {

        curriculum,

        nodes: [],

        edges: []

    };

}