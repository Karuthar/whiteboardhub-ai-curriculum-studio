import { buildKnowledgeGraph } from "./graphBuilder.js";
import { createRelationships } from "./graphRelationships.js";
import { serializeGraph } from "./graphSerializer.js";

export async function generateKnowledgeGraph(curriculum) {

    const graph =
        buildKnowledgeGraph(curriculum);

    createRelationships(graph);

    return serializeGraph(graph);

}