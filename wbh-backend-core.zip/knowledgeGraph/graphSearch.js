export function searchGraph(graph, query) {

    return [];

}