const graphCache = new Map();

export function saveGraph(id, graph) {

    graphCache.set(id, graph);

}

export function loadGraph(id) {

    return graphCache.get(id);

}