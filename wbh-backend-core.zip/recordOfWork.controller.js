import LessonPlan from "../models/lessonPlan.model.js";
import RecordOfWork from "../models/recordOfWork.model.js";

export async function generateRecordOfWork(req, res) {
  try {
    const { lessonPlanId } = req.params;

    const lessonPlan = await LessonPlan.findById(lessonPlanId);

    if (!lessonPlan) {
      return res.status(404).json({
        success: false,
        message: "Lesson plan not found"
      });
    }

    const lessonLabel =
      lessonPlan.durationMinutes >= 80
        ? `${lessonPlan.lessonNumber} & ${Number(lessonPlan.lessonNumber) + 1}`
        : lessonPlan.lessonNumber;

    const workCovered = [
      lessonPlan.lessonTitle,
      lessonPlan.subStrand,
      ...(lessonPlan.learningOutcomes || [])
    ]
      .filter(Boolean)
      .join(" — ");

    const record = await RecordOfWork.create({
      schemeId: lessonPlan.schemeId,
      lessonPlanId: lessonPlan._id,
      curriculumId: lessonPlan.curriculumId,

      subject: lessonPlan.subject,
      grade: lessonPlan.grade,
      termNumber: lessonPlan.termNumber,
      weekNumber: lessonPlan.weekNumber,
      lessonNumber: lessonLabel,

      strand: lessonPlan.strand || "",
      subStrand: lessonPlan.subStrand || "",
      workCovered,

      reference:
        "KICD Curriculum Design, Approved Biology Textbook, Teacher Notes",

      remarks: "Lesson covered as planned.",
      generatedBy: "system"
    });

    res.status(201).json({
      success: true,
      message: "Record of work generated successfully",
      record
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to generate record of work",
      error: error.message
    });
  }
}

export async function getRecordsOfWork(req, res) {
  try {
    const records = await RecordOfWork.find()
      .populate("lessonPlanId")
      .populate("schemeId")
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      count: records.length,
      records
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch records of work",
      error: error.message
    });
  }
}

export async function getRecordOfWorkById(req, res) {
  try {
    const { recordId } = req.params;

    const record = await RecordOfWork.findById(recordId)
      .populate("lessonPlanId")
      .populate("schemeId");

    if (!record) {
      return res.status(404).json({
        success: false,
        message: "Record of work not found"
      });
    }

    res.json({
      success: true,
      record
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch record of work",
      error: error.message
    });
  }
}

export async function deleteRecordOfWork(req, res) {
  try {
    const { recordId } = req.params;

    await RecordOfWork.findByIdAndDelete(recordId);

    res.json({
      success: true,
      message: "Record of work deleted successfully"
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to delete record of work",
      error: error.message
    });
  }
}